load Metrics_Test_251123.mat
font_Size = 12;
%% Bench
RMSE_Bench_h = Metrics_Bench.RMSE_h;
ERR_Bench = Metrics_Bench.ERR;

%% Pers
RMSE_Pers_h = Metrics_Pers.RMSE_h;
ERR_Pers    = Metrics_Pers.ERR;

%% LSTM
for r = 1:4
    for c = 1:10
        index = (r-1)*10 + c;
        RMSE_LSTM_h_app(index,:) = Metrics_LSTM(r,c).RMSE_h;
        ERR_LSTM_app(index,:)    = Metrics_LSTM(r,c).ERR;
    end
end

RMSE_LSTM_h = mean(RMSE_LSTM_h_app,1);
ERR_LSTM    = mean(ERR_LSTM_app,1);

%% CVNN
for c = 1:10
    RMSE_CVNN_UC_h_app(c,:)   = Metrics_Test(1,c).RMSE_h;
    ERR_CVNN_UC_app(c,:)      = Metrics_Test(1,c).ERR;

    RMSE_CVNN_FFT1_h_app(c,:) = Metrics_Test(2,c).RMSE_h;
    ERR_CVNN_FFT1_app(c,:)    = Metrics_Test(2,c).ERR;

    RMSE_CVNN_FFT2_h_app(c,:) = Metrics_Test(3,c).RMSE_h;
    ERR_CVNN_FFT2_app(c,:)    = Metrics_Test(3,c).ERR;

    RMSE_CVNN_DAY_h_app(c,:)  = Metrics_Test(4,c).RMSE_h;
    ERR_CVNN_DAY_app(c,:)     = Metrics_Test(4,c).ERR;
end

RMSE_CVNN_UC_h   = mean(RMSE_CVNN_UC_h_app,1);
ERR_CVNN_UC      = mean(ERR_CVNN_UC_app,1);

RMSE_CVNN_FFT1_h = mean(RMSE_CVNN_FFT1_h_app,1);
ERR_CVNN_FFT1    = mean(ERR_CVNN_FFT1_app,1);

RMSE_CVNN_FFT2_h = mean(RMSE_CVNN_FFT2_h_app,1);
ERR_CVNN_FFT2    = mean(ERR_CVNN_FFT2_app,1);

RMSE_CVNN_DAY_h  = mean(RMSE_CVNN_DAY_h_app,1);
ERR_CVNN_DAY     = mean(ERR_CVNN_DAY_app,1);

%% Plot
figure(10)
subplot(1,2,1)
% plot(RMSE_Bench_h,'.-')
plot(RMSE_Pers_h,'.-')
hold on
plot(RMSE_LSTM_h,'.-')
plot(RMSE_CVNN_UC_h,'.-')
plot(RMSE_CVNN_FFT1_h,'.-')
plot(RMSE_CVNN_FFT2_h,'.-')
plot(RMSE_CVNN_DAY_h,'.-')
hold off
grid on
title('RMSE Comparison')
legend("Mov. Mean", "Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")

subplot(1,2,2)
% plot(ERR_Bench,'.-')
plot(ERR_Pers,'.-')
hold on
plot(ERR_LSTM,'.-')
plot(ERR_CVNN_UC,'.-')
plot(ERR_CVNN_FFT1,'.-')
plot(ERR_CVNN_FFT2,'.-')
plot(ERR_CVNN_DAY,'.-')
hold off
grid on
title('ERR Comparison')
legend("Mov. Mean", "Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")

%% Plot
figure(11)
subplot(1,2,1)
% plot(RMSE_Bench_h,'.-')
plot(RMSE_Pers_h,'.-')
hold on
plot(smoothdata(RMSE_LSTM_h, 'movmean', 5),'.-',LineWidth=2)
plot(smoothdata(RMSE_CVNN_UC_h, 'movmean', 5),'.-')
plot(smoothdata(RMSE_CVNN_FFT1_h, 'movmean', 5),'.-')
plot(smoothdata(RMSE_CVNN_FFT2_h, 'movmean', 5),'.-')
plot(smoothdata(RMSE_CVNN_DAY_h, 'movmean', 5),'.-')
hold off
grid on
title('RMSE Comparison')
legend("Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")

subplot(1,2,2)
% plot(ERR_Bench,'.-')
plot(ERR_Pers,'.-')
hold on
plot(smoothdata(ERR_LSTM, 'movmean', 5),'.-')
plot(smoothdata(ERR_CVNN_UC, 'movmean', 5),'.-')
plot(smoothdata(ERR_CVNN_FFT1, 'movmean', 5),'.-')
plot(smoothdata(ERR_CVNN_FFT2, 'movmean', 5),'.-')
plot(smoothdata(ERR_CVNN_DAY, 'movmean', 5),'.-')
hold off
grid on
title('ERR Comparison')
legend("Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")

%% Plot
LW = 1.5;
MS = 8;

figure(12)
subplot(1,2,1)
plot(RMSE_Pers_h,'.-',LineWidth=LW,MarkerSize=MS)
hold on
plot(RMSE_LSTM_h,'x-',LineWidth=LW,MarkerSize=MS)
plot(RMSE_CVNN_UC_h,'.-',LineWidth=LW,MarkerSize=MS)
plot(RMSE_CVNN_FFT1_h,'.-',LineWidth=LW,MarkerSize=MS)
plot(RMSE_CVNN_FFT2_h,'.-',LineWidth=LW,MarkerSize=MS)
plot(RMSE_CVNN_DAY_h,'.-',LineWidth=LW,MarkerSize=MS)
hold off
grid on
title('RMSE Comparison')
legend("Mov. Mean", "Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")
xlabel('steps','FontSize',font_Size,'FontWeight','bold')
ylabel('Active Power','FontSize',font_Size,'FontWeight','bold')
ax = gca;  % ottieni l'asse corrente
ax.FontName = 'Times New Roman'; % Cambia il font delle tick labels
ax.FontSize = font_Size; % Cambia la dimensione del font

subplot(1,2,2)
% plot(ERR_Bench,'.-')
plot(ERR_Pers,'.-',LineWidth=LW,MarkerSize=MS)
hold on
plot(smoothdata(ERR_LSTM, 'movmean', 5),'x-',LineWidth=LW,MarkerSize=MS)
plot(smoothdata(ERR_CVNN_UC, 'movmean', 5),'.-',LineWidth=LW,MarkerSize=MS)
plot(smoothdata(ERR_CVNN_FFT1, 'movmean', 5),'.-',LineWidth=LW,MarkerSize=MS)
plot(smoothdata(ERR_CVNN_FFT2, 'movmean', 5),'.-',LineWidth=LW,MarkerSize=MS)
plot(smoothdata(ERR_CVNN_DAY, 'movmean', 5),'.-',LineWidth=LW,MarkerSize=MS)
hold off
grid on
title('ERR Comparison')
legend("Pers", "LSTM", "CVNN UC", "CVNN FFT1", "CVNN FFT2", "CVNN DAY")
xlabel('steps','FontSize',font_Size,'FontWeight','bold')
ylabel('Active Power','FontSize',font_Size,'FontWeight','bold')
ax = gca;  % ottieni l'asse corrente
ax.FontName = 'Times New Roman'; % Cambia il font delle tick labels
ax.FontSize = font_Size; % Cambia la dimensione del font