function [LSTM_result_org] = LSTM_Output_Organizer(LSTM_result)

numSeq = size(LSTM_result,1);
for i = numSeq:-1:1
    LSTM_result_app = LSTM_result{i};
    LSTM_result_org(:,:,i) = LSTM_result_app;
end   

LSTM_result_org = permute(LSTM_result_org,[3 2 1]);