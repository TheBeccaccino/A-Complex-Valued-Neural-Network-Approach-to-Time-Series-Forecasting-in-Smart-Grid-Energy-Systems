%% Preprocessing for normalization on unit circle
function [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_unit_circle(Learn_set, Test_set, O1, O2, start_indx, stop_indx, N_of_Input)

%%% Normalizzazione sul cerchio unitario
max_sector = O1 + O2;
safe_sector = O2;
used_sector = O1;

%%% Normalizzazione Log
% Train Set
Learn_Log_app = log(Learn_set + 1);
Min_Train_Log = min(Learn_Log_app,[],"all")*0.5;
Learn_Log_app = (Learn_Log_app - Min_Train_Log);

Train_Log_Norm = used_sector/(max(Learn_Log_app,[],"all")*1.5);
Train_Log_Offset = safe_sector;
Train_Log_set = (Learn_Log_app * Train_Log_Norm) + Train_Log_Offset;

% Test Set
Test_Log_app = log(Test_set + 1);
Test_Log_app = (Test_Log_app - Min_Train_Log);
Test_Log_set = (Test_Log_app * Train_Log_Norm) + Train_Log_Offset;  

Input_learn = Train_Log_set(:,start_indx:stop_indx);
Input_test = Test_Log_set(:,start_indx:stop_indx);

Input_learn_processed = exp(1i .* Input_learn);
Input_test_processed = exp(1i .* Input_test);

%% parameters
parameters.Log_Norm = Train_Log_Norm;
parameters.Log_Min = Min_Train_Log;
parameters.Log_Offset = Train_Log_Offset;

% Sets
Sets.Learn_Original_Input   = Learn_set(:,1:N_of_Input);
Sets.Learn_Original_Output  = Learn_set(:,1:N_of_Input);
Sets.Learn_Processed_Input  = Input_learn_processed(:,1:N_of_Input);
Sets.Learn_Processed_Output = Input_learn_processed(:,N_of_Input+1:end);

Sets.Test_Original_Input   = Test_set(:,1:N_of_Input);
Sets.Test_Original_Output  = Test_set(:,1:N_of_Input);
Sets.Test_Processed_Input  = Input_test_processed(:,1:N_of_Input);
Sets.Test_Processed_Output = Input_test_processed(:,N_of_Input+1:end);
