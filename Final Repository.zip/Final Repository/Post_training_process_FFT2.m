function [errors] = Post_training_process(Results, N_of_Input, N_of_Output, max_input_learn, fig1_N, fig2_N, N_of_Output_red, Input_learn_offset)
%% Results unzip
train_output = Results.train_output;
val_output = Results.val_output;
des_train_output = Results.des_train_output;
des_val_output = Results.des_val_output;

%% Errors on the spectrums
% error_train_pre = mean(abs(train_output) - abs(des_train_output),1);
% error_val_pre = mean(abs(val_output) - abs(des_val_output),1); 
error_train_pre = mean(train_output - des_train_output,1);
error_val_pre = mean(val_output - des_val_output,1);

%% postprocess of the resulting output
%%% Training
Train_size_2 = size(train_output);
Train_offset = Input_learn_offset(1:Train_size_2(1),1);
[train_output] = postprocess_with_FFT_2(train_output, N_of_Output, N_of_Output_red, Train_offset);
[des_train_output] = postprocess_with_FFT_2(des_train_output, N_of_Output, N_of_Output_red, Train_offset);
max_input_train = max_input_learn(1:Train_size_2(1), N_of_Input+1:end);
[real_train_output] = postprocess_2(train_output, N_of_Output, max_input_train);
[real_des_train_output] = postprocess_2(des_train_output, N_of_Output, max_input_train);

%%% Validation
Val_size_2 = size(val_output);
Val_offset = Input_learn_offset((Train_size_2(1)+1):end,1);
[val_output] = postprocess_with_FFT_2(val_output, N_of_Output, N_of_Output_red, Val_offset);
[des_val_output] = postprocess_with_FFT_2(des_val_output, N_of_Output, N_of_Output_red, Val_offset);
max_input_val = max_input_learn(Train_size_2(1)+1:end, N_of_Input+1:end);
[real_val_output] = postprocess_2(val_output, N_of_Output, max_input_val);
[real_des_val_output] = postprocess_2(des_val_output, N_of_Output, max_input_val);

error_train_post = mean(real_train_output - real_des_train_output,1);
error_val_post = mean(real_val_output - real_des_val_output,1); 

%% Plots
t = 'Train result example';
p = 1;
[a] = fft_plot(real_des_train_output, real_train_output, des_train_output, train_output, t, fig1_N, p);

t = 'Validation result example';
p = 1;
[a] = fft_plot(real_des_val_output, real_val_output, des_val_output, val_output, t, fig2_N, p);

%% Output
errors.train_pre = error_train_pre;
errors.val_pre = error_val_pre;
errors.train_post = error_train_post;
errors.val_post = error_val_post;
