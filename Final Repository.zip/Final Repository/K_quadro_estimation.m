function [sigma_low,sigma_high, avg] = K_quadro_estimation(x, alpha, perc_mask)
%%% Filtraggio Outlayer
% costruzione della maschera dei percentili
ub = 100 - perc_mask;
lb = perc_mask;
p = prctile(x, [lb ub]);
mask = x >= p(1) & x <= p(2);
x1 = x(mask);

%%% Calcolo della media
avg = mean(x1);

%%% definizione del intervalo di confidenza
% Parametri di base
n = length(x1);
df = n - 1;

% Deviazione standard campionaria (correzione di Bessel)
s = std(x1, 1); % std(x,1) usa la formula con n (varianza della popolazione)
% Attenzione: per la stima campionaria si usa std(x,0)
s = std(x1, 0); % usa n-1 nel denominatore (corretto per campione)

% Quantili della distribuzione chi-quadrato
chi2_high = chi2inv(1 - alpha/2, df);
chi2_low = chi2inv(alpha/2, df);

% Limiti dell’intervallo di confidenza per la deviazione standard
sigma_low = sqrt((df * s^2) / chi2_low);
sigma_high = sqrt((df * s^2) / chi2_high);

% Output leggibile
fprintf('Deviazione standard campionaria: %.3f\n', s);
fprintf('Intervallo di confidenza al 95%%: [%.3f , %.3f]\n', sigma_low, sigma_high);