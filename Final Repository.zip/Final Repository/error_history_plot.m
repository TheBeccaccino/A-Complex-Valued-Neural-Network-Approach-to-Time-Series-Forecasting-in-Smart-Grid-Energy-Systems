function [err_history, ang_RMSE_history] = error_history_plot(err_all, err_val, err_val_min, ang_RMSE, ang_RMSE_val, err_history, ang_RMSE_history, iterations, N_fig, y_max)

    err_history(1,iterations) = err_all;
    err_history(2,iterations) = err_val;

    ang_RMSE_history(1,iterations) = ang_RMSE;
    ang_RMSE_history(2,iterations) = ang_RMSE_val;

    %%% Error string
    error_string = sprintf('iteration:%d', iterations);
    
    figure(N_fig)
    sgtitle(error_string)

    subplot(1,4,1)
    s = sprintf('Euclidian Error train:%d val:%d ', abs(err_all), abs(err_val));
    plot(abs(err_history(1, 1:iterations)))
    title(s)
    hold on
    plot(abs(err_history(2, 1:iterations)))
    grid on
    hold off

    subplot(1,4,2)
    s1 = sprintf('val min:%d', abs(err_val_min));
    plot(abs(err_history(1, 1:iterations)))
    title(s1)
    hold on
    plot(abs(err_history(2, 1:iterations)))
    grid on
    ylim([0 y_max])
    hold off

    subplot(1,2,2)
    s2 = sprintf('Angular RMSE train:%d val:%d', ang_RMSE, ang_RMSE_val);
    plot(abs(ang_RMSE_history(1,1:iterations)))
    title(s2)
    hold on
    plot(abs(ang_RMSE_history(2,1:iterations)))
    grid on
    hold off