%% CLeared Code for MLMVN applied to the household load forecasting in case of only active power available
% Possibility to choose between unit circle normalization of FFT 
clear
% close all

%%

%% Setup
e = 2.72;
load Australian_dataset_load.mat    % Load of Ausgrid dataset
load tubitex_dataset.mat

%% Choice of the profile and of the elaboration type
u = 35;  % Choose of the user in the dataset
%choose of the type of elaboration of the data
Elab_type = 3; % 0-> norm on unit circle, 1-> FFT, 2-> Short FFT, 3-> Day of the week

for u = 127:-1:1
    for Elab_type = 1
        
        %% Preliminary elaboration
        E_load_h_all;
        % We can choose the size of the Input and output sequences. The code can
        % already do different test for different combination to compare the performances if the size arrays have more than one option
        Input_size_array = 72; %[1,6,12,24,48,72];  % Experiment performed with 72 Input sequence
        n_input_size = size(Input_size_array,2);
        Output_size_array = 72; %[1,6,12,24,48,72]; % Experiment performed with 72 Output sequence
        n_output_size = size(Output_size_array,2);
        
        max_input_size = max(Input_size_array,[],"all");
        max_output_size = max(Output_size_array,[],"all");
        
        % Data_size = size(tubitex_cmplx_1h(:,u),1);
        Data_size = size(E_load_h_all,1);
        N_of_days = ceil(Data_size/24);
        N_of_weeks = ceil(N_of_days/7);
        day_indexes = repmat((1:7),24,N_of_weeks);
        hour_indexes = reshape(day_indexes(:,1:N_of_days),[],1);
        
        N_of_set = Data_size - max_input_size - max_output_size; % Number of possible set of data to be divided in train and test
        
        % Choose of the sector in which normilize the data in caso of unit circle
        % normalization, In this case O1 ~ 45° and O2 ~ 30°
        sector_unit = pi/12; %rad
        O1 = 24*sector_unit;%(2+1) * sector_unit; %ampiezza settore angolare | 38°
        O2 = 0;%(3-1) * sector_unit; %ampiezza offset             | 68°
        O1_list = O1; %[12 10 8 6 4 2.5 2.3] * sector_unit;
        
        %choose of the type of elaboration of the data
        % Elab_type = 3; % 0-> norm on unit circle, 1-> FFT, 2-> Short FFT, 3-> Day of the week
        
        % Define the architecture of your network. To this particular problem it
        % seems that 75 neuron in the first layer and 100 in the second is the best
        % configuration
        hiddenLayerSize_1_list = 75;%75; %[10 10 20 30 70 75];% Number of neurons in the first hidden layer
        hiddenLayerSize_2_list = 100;% [70 70 80 80 90 100];% Number of neurons in the second hidden layer
        %number of epochs
        n_epoch = 800;
        % chose of the activation functions of each layer
        fun_h1 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
        fun_h2 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
        fun_out = 'log'; %options: non-> no operation performed, log-> logaritmic norm, max-> max normalization
        
        type(1,:) = fun_h1;
        type(2,:) = fun_h2;
        type(3,:) = fun_out;
        
        % plot_on
        plot_on = 0;
        
        % Sets parameters
        n_of_train_months = 3;
        n_of_months_in_daset = 8;
        max_m = n_of_months_in_daset - n_of_train_months;
        validation_size = 0.10;
        
        Train_size = n_of_train_months*30*24;%fix(Data_size*0.1); 
        Validation_size = fix(Train_size * validation_size);
        
        Learn_size =Train_size; %Validation_size + 
        Test_size = 20*24;%Learn_size;%
        
        % Set Generation: In this section the Learning and Test set are extracted from the Data set
        % Data = real(tubitex_cmplx_1h(:,u));
        Data = real(E_load_h_all(:,u));
        Overlap = 0;
        for d = N_of_set:-1:1
            input_index  = (1:max_input_size)  + d-1;
            output_index = (1:max_output_size) + d-1 + max_input_size - Overlap;
            set_Data(d,:)       = [Data(input_index); Data(output_index)];
            set_Data_index(d,:) = [hour_indexes(input_index); hour_indexes(output_index)];
        end
        
        %% Start of the loop, we can decide to performe multiple experiment in which we shift the chosed sets
        
        for m= max_m:-1:1 %m = 1%
            disp([u Elab_type m])
            %% Ordered Generation of Learn & Test set
            % dimension 1
            offset = (m-1)*30*24;
            stop_indx = Learn_size + Test_size;
        
            % dimension 2
            start_indx_2 = 1;
            stop_indx_2 = max_input_size + max_output_size;
        
            % Learn and Test set used
            Learn_set = set_Data(1+offset:Learn_size+offset,:);
            Test_set  = set_Data(Learn_size+1+offset:stop_indx+offset,:);
            Learn_set_index = set_Data_index(1+offset:Learn_size+offset,:);
            Test_set_index  = set_Data_index(Learn_size+1+offset:stop_indx+offset,:);
        
            Output_test_original = set_Data(Learn_size+1+offset:stop_indx+offset,max_input_size+1:max_input_size+max_output_size);
            Input_test_plot = Test_set;
        
        
            %% Benchmark: weighted mobile mean with exponential smoothing
            %%% Solution to forecast that not require neural networks, used as benchmark comparison
            options_wbench.memory_weight = 0.95;
            options_wbench.input_size = max_input_size;
            [Mean_sequence,Pers_sequence,Output_desired] = weight_benchmark(Learn_set, Test_set, options_wbench);
        
            %% Code for the different Input-Output size combination
            Input_size_indx = 1;
            Output_size_indx = 1;
        
                %% Setup 
                hiddenLayerSize_1 = hiddenLayerSize_1_list(Input_size_indx);
                hiddenLayerSize_2 = hiddenLayerSize_2_list(Input_size_indx);
                hidsize = [hiddenLayerSize_1 hiddenLayerSize_2];
        
                N_of_Input = Input_size_array(Input_size_indx);
                N_of_Output = Output_size_array(Output_size_indx);
                N_of_Input_app = N_of_Input;
                N_of_Output_app = N_of_Output;
                
                disp([m, N_of_Input, N_of_Output, hidsize, O1])
        
                %%% dimension of the set
                % dimensione 1
                offset = (m-1)*30*24;
                stop_indx = Learn_size + Test_size;
            
                % dimensione 2
                start_indx_2 = max_input_size - N_of_Input + 1;
                stop_indx_2 = max_input_size + N_of_Output;
        

                %% Benchmark 2:LSTM
                %%% 
                Power_train_LSTM = Learn_set(:,start_indx_2:stop_indx_2);
                Power_test_LSTM = Test_set(:,start_indx_2:stop_indx_2); 
                % 
                Power_train_LSTM = log(Power_train_LSTM + 1);
                Power_test_LSTM  = log(Power_test_LSTM + 1);
        
                Max_train = max(Power_train_LSTM(:, 1:N_of_Input),[],"all");
        
                Power_norm_train_LSTM = Power_train_LSTM./Max_train;
                Power_norm_test_LSTM  = Power_test_LSTM ./Max_train;
        
        
                sector = 2*pi/7;
        
                % Input_train_LSTM = cat(3, Power_norm_train_LSTM);
                % Input_test_LSTM  = cat(3, Power_norm_test_LSTM);
                Input_train_LSTM = cat(3, Power_norm_train_LSTM, sin(Learn_set_index*sector), cos(Learn_set_index*sector));
                Input_test_LSTM  = cat(3, Power_norm_test_LSTM, sin(Test_set_index*sector), cos(Test_set_index*sector));  
        
                
                numFeatures = N_of_Input;
                numHiddenUnits = 40;
                numResponses = N_of_Output;       
        
                % [x_train_app, t_train_app] = LSTM_Data_Organizer(Input_train_LSTM, N_of_Input, N_of_Output, numFeatures);
                % [x_test_app, t_test_app]   = LSTM_Data_Organizer(Input_test_LSTM, N_of_Input, N_of_Output, numFeatures);
                [x_train_app, t_train_app] = LSTM_Data_Organizer_2(Input_train_LSTM, N_of_Input, N_of_Output, numFeatures);
                [x_test_app, t_test_app]   = LSTM_Data_Organizer_2(Input_test_LSTM, N_of_Input, N_of_Output, numFeatures);
        
        
                weights = [(11:-2:3), 2*ones(1,15), ones(1,N_of_Output-Overlap -20)];
                % myLoss = weightedSeqRegressionLayer(weights, "weightedMSE");
                %%% Network Layers
                layers = [ ...
                    sequenceInputLayer(numFeatures, Name="sequenceinput")
                    lstmLayer(numHiddenUnits, OutputMode="sequence", Name="lstm")
                    fullyConnectedLayer(numFeatures, Name="fc")
                    regressionLayer
                    % weightedSeqRegressionLayer(weights, "weightedMSE")
                    ];
                % %            
                    % 
        
                maxEpochs = 200;
                miniBatchSize = 64;
                valFrequency = 10;
                valPerc = 0.05;
                lossFcn = 'mse';
                [x_train_app, t_train_app, x_val_app, t_val_app] = validation_split(x_train_app, t_train_app, valPerc);
        
        
                options = trainingOptions('adam', ...
                'MaxEpochs',maxEpochs, ...
                'MiniBatchSize',miniBatchSize, ...
                'InitialLearnRate',0.001, ...
                'GradientThreshold',10, ...
                'Shuffle','every-epoch', ...
                'Plots','none',... 
                'ValidationData',{x_val_app, t_val_app}, ...      % <-- validation set
                'ValidationFrequency',valFrequency, ...           % ogni quanto valutare
                'ValidationPatience',10, ...                      % quante volte senza migliorare prima di fermarsi
                'OutputNetwork','best-validation', ...       % prendi la rete col miglior val loss
                'L2Regularization',1e-4, ...
                'Verbose',0);%                   
            
                net = trainNetwork(x_train_app,t_train_app,layers,options);
                 % net = trainnet(x_train_app,t_train_app,layers,lossFcn,options);
        
                y_test_app = predict(net,x_test_app,'MiniBatchSize',64);
        
                % [y_test_org] = LSTM_Output_Organizer(y_test_app);
                % [t_test_org] = LSTM_Output_Organizer(t_test_app);
                [y_test_org] = LSTM_Output_Organizer_2(y_test_app);
                [t_test_org] = LSTM_Output_Organizer_2(t_test_app);
        
                Power_norm_y_test = y_test_org(:,:,1);
                Power_norm_t_test = t_test_org(:,:,1);
        
                Power_y_test = Power_norm_y_test * Max_train;
                Power_t_test = Power_norm_t_test * Max_train;
        
                Power_y_test = exp(Power_y_test) - 1;
                Power_t_test = exp(Power_t_test) - 1;
                
                %% Metrics 
        
                %%% Metrics Evaluation
                [Metrics_LSTM] = metrics_evaluation (Power_y_test, Power_t_test);

                Result_app(m).Output_desired      = Power_t_test;
                Result_app(m).real_output         = Power_y_test;
                Result_app(m).Metrics_LSTM        = Metrics_LSTM;
        
                Results(u).Elab_type(Elab_type+1).Result_app=Result_app;
                save Results_LSTM.mat Results
        end
    end
end