function [a] = comparison_plot(MLMVN_output, LSTM_output, Bench_sequence, Desired_output, t, fig_N, p)
            figure(fig_N)
            sgtitle(t) % 


            plot(MLMVN_output(p,:),'.-')
            title("Output of the Network: Real Postprocessed Output")
            hold on
            plot(LSTM_output(p,:),'.-')
            plot(Bench_sequence(p,:),'.-')
            plot(Desired_output(p,:),'.-')
            grid on
            legend('MLMVN output', 'LSTM output', 'Bench','Desired output')
            hold off

            a=1;

