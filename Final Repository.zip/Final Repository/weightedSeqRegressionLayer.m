classdef weightedSeqRegressionLayer < nnet.layer.RegressionLayer
    properties
        Weights
    end
    
    methods
        function layer = weightedSeqRegressionLayer(weights, name)
            layer.Name = name;
            layer.Weights = weights;
        end
        
        function loss = forwardLoss(layer, Y, T)
            % Y, T size: [numResponses, numTimeSteps, miniBatchSize]
            W = reshape(layer.Weights, 1, [], 1);  % [1, numTimeSteps, 1]
            W = permute(W, [3 1 2]);
            diffs = Y - T;
            sq = diffs.^2;
            sqWeighted = sq .* W;
            loss = mean(sqWeighted, 'all');
        end
    end
end