function [Results] = Net_test_expanded(Input, Network)

% This function utilizes the MLMVN test after batch learning algorithm for
% a network containing 2 hidden layers and multiple output neurons
% This version of the function supports only continuous inputs and
% continuous output

% Description of input parameters:
% Input - matrix of MVN inputs (N x (n+m)), where N=number of learning
% samples, n = number of inputs, the m last columns of this matrix represent 
% desired outputs. Each row of this matrix is a learning sample - inputs
% followed by the desired output
%
% Network -> struct with the following fields:
% hidneur_weights1: weights of all neurons from the 1st hidden layer
% hidneur_weights2: weights of all neurons from the 2nd hidden layer
% outneur_w: weights of output neuron
%
% options: setup taken from the learning process of which we are going to
% use:
% n_of_outputs - allow to identify how many of the last coloumns are to be
% considered as output
%
% type - vector of 3 strings, it represent the tipe of activation function
% used in each layer. Available options: 
% - abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
% - abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
% - non-> no operation performed, log-> logaritmic norm, max-> max normalization
%
% plot_on - first enable plot of errors, second enable plot of the output
% of the layers

%Description of output parameters:
%
% ang_RMSE - test angular RMSE
% current_phase - actual outputs
% y_d - desired outputs taken from the last column of Input
%

%% Network Unzip
hidneur_weights1 = Network.hidneur_weights1;
hidneur_weights2 = Network.hidneur_weights2;
outneur_w = Network.outneur_w;
max_hidden = Network.max_hidden;
options = Network.option;

type = options.type;
n_of_outputs = options.n_of_outputs;

%% Execution of the Network
%Determine the number of testing samples and number of inputs
[N, m] = size(Input);
n = m-n_of_outputs;
X = Input(:,1:n);
y_d = Input(:,n+1:end);

%append a column of 1s to X from the left
%app_X
col_app(1:N) = 1;
col_app = col_app.';
app_X = [col_app X];

%%%  Compute the output of the 1st hidden neurons for all samples 
hid_outmat1 = app_X * hidneur_weights1;

% 1st Hidden Layer: execution of the choose activation function
abs_hid_outmat1 = abs(hid_outmat1);
if strcmp(type(1,:),'abs')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1);
elseif strcmp(type(1,:),'log')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* log(abs_hid_outmat1+1);
elseif strcmp(type(1,:),'tan')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* tanh(abs_hid_outmat1);
end

%%% Division for the max of the output to bring everything in the unit
%%% circle
hid_outmat1 = hid_outmat1/max_hidden(1);

% append a column of 1s to X1 from the left
app_X1 = [col_app hid_outmat1];

%%%  Compute the output of the 2nd hidden neurons for all samples 
hid_outmat2 = app_X1 * hidneur_weights2;

% 2st Hidden Layer: execution of the choose activation function
abs_hid_outmat2 = abs(hid_outmat2);
if strcmp(type(2,:),'abs')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2);
elseif strcmp(type(2,:),'log')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* log(abs_hid_outmat2+1);
elseif strcmp(type(2,:),'tan')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* tanh(abs_hid_outmat2);
end

%%% Division for the max of the output to bring everything in the unit
%%% circle
hid_outmat2 = hid_outmat2/max_hidden(2);

%append a column of 1s to hid_outmat
hid_outmat2 = [col_app hid_outmat2];

%%%  Compute the output of the Output Layer for all samples 
z_outneur = hid_outmat2 * outneur_w;

% Output Layer: execution of the choose activation function
abs_z_outneur = abs(z_outneur);
max_z_out = max(abs(z_outneur),[],"all");
if strcmp(type(3,:),'non')
    z_outneur = z_outneur;
elseif strcmp(type(3,:),'abs')
    z_outneur = (z_outneur./abs_z_outneur);
elseif strcmp(type(3,:),'log')
    z_outneur = (z_outneur./abs_z_outneur) .* log(abs_z_outneur+1);
elseif strcmp(type(3,:),'max')
    z_outneur = (z_outneur./max_z_out);
end

%% Test_error
%%% Euclidian Error
error_app = abs(y_d - z_outneur);
err_all = error_app.^2;
err_all = sqrt(mean(err_all,2));
err_all = mean(err_all,"all");

%%% Angular RMSE
ang_err = abs(angle(y_d) - angle(z_outneur));
if ang_err > pi
    ang_err = 2*pi - ang_err;
end
ang_RMSE = ang_err.^2;
ang_RMSE = sqrt(mean(ang_RMSE,2));
ang_RMSE = mean(ang_RMSE,"all");

% Flags contin 1 at the positions where current_pase differs from the
Flags = (angle(y_d) ~= angle(z_outneur));
% nesovpad is the number of errors over the entire learning set
nesovpad = sum(Flags);

%% Results
% Results
Results.test_output = z_outneur;
Results.des_test_output = y_d;




