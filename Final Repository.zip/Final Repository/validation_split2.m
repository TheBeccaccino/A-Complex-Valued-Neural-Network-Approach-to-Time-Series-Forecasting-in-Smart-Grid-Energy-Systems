function [x_train_app, t_train_app, x_val_app, t_val_app] = validation_split(x_app, t_app, val_perc)

%%% Setup
train_perc = 1 - val_perc;
numSamples = size(x_app,3);
idxTrain   = 1:round(train_perc*numSamples);
idxVal     = round(train_perc*numSamples)+1:numSamples;

%%% Train set
x_train_app = x_app(:,:,idxTrain);
t_train_app = t_app(:,:,idxTrain);

%%% Validation set
x_val_app = x_app(:,:,idxVal);
t_val_app = t_app(:,:,idxVal);