function [a] = input_complex_plot(original_seq, processed_seq, t, fig_N, indx)
    font_Size = 10;

    In_process = figure(fig_N)
    % sgtitle(t, FontName='Times New Roman') % 
    p = indx;
    In_process.Position = [100 100 1200 400];


    subplot(1,2,1)
    plot(original_seq(p,:),'.-')
    title("Original Sequence", FontName='Times New Roman')
    grid on
    xlabel('steps','FontSize',font_Size,'FontWeight','bold')
    ylabel('Active Power','FontSize',font_Size,'FontWeight','bold')
    ax = gca;  % ottieni l'asse corrente
    ax.FontName = 'Times New Roman'; % Cambia il font delle tick labels
    ax.FontSize = font_Size; % Cambia la dimensione del font

    subplot(2,2,2)
    plot(abs(processed_seq(p,:)),'.-')
    title("Processed Sequence: Spectrum magnitude", FontName='Times New Roman')
    grid on
    % xlabel('steps','FontSize',font_Size,'FontWeight','bold')
    ylabel('magnitude','FontSize',font_Size,'FontWeight','bold')
    ax = gca;  % ottieni l'asse corrente
    ax.FontName = 'Times New Roman'; % Cambia il font delle tick labels
    ax.FontSize = font_Size; % Cambia la dimensione del font

    subplot(2,2,4)
    plot(angle(processed_seq(p,:)),'.-')
    title("Processed Sequence: Spectrum angle", FontName='Times New Roman')
    grid on  
    xlabel('steps','FontSize',font_Size,'FontWeight','bold')
    ylabel('magnitude','FontSize',font_Size,'FontWeight','bold')
    ylim([-pi*1.1 pi*1.1])
    yticks([-pi -pi/2 0 pi/2 pi]);
    yticklabels({'-π', '-π/2', '0', 'π/2', 'π'})
    ax = gca;  % ottieni l'asse corrente
    ax.FontName = 'Times New Roman'; % Cambia il font delle tick labels
    ax.FontSize = font_Size; % Cambia la dimensione del font

    
    
    % xticks([1, 3:3:24])
    % xlim([0 25])
            a=1;

