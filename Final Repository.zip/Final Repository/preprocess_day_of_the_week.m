%% Preprocessing for normalization on unit circle
function [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_day_of_the_week(Learn_set, Test_set, O1, O2, start_indx, stop_indx, Learn_set_indx, Test_set_indx, N_of_Input)

%%% Normalizzazione sul cerchio unitario
max_sector = O1 + O2;
safe_sector = O2;
used_sector = O1;

%%% Normalizzazione Log
%%% Train Set
% module
Learn_Log_app = log(Learn_set + 1);
Min_Train_Log = 0;%min(Learn_Log_app,[],"all");
Max_Train_Log = max(Learn_Log_app,[],"all");
Learn_Log_app = (Learn_Log_app - Min_Train_Log) / (Max_Train_Log - Min_Train_Log);

% phase
Learn_angle_app = Learn_set_indx * O1/7 + O2;

% SET
Input_learn_processed = Learn_Log_app .* exp(1i .* Learn_angle_app);

%%% Test Set
% module
Test_Log_app = log(Test_set + 1);
Test_Log_app = (Test_Log_app - Min_Train_Log) / (Max_Train_Log - Min_Train_Log);

% phase
Test_angle_app = Test_set_indx * O1/7 + O2;

% SET 
Input_test_processed = Test_Log_app .* exp(1i .* Test_angle_app);

%% parameters
parameters.Log_Max = Max_Train_Log;
parameters.Log_Min = Min_Train_Log;

% Sets
Sets.Learn_Original_Input   = Learn_set(:,1:N_of_Input);
Sets.Learn_Original_Output  = Learn_set(:,1:N_of_Input);
Sets.Learn_Processed_Input  = Input_learn_processed(:,1:N_of_Input);
Sets.Learn_Processed_Output = Input_learn_processed(:,N_of_Input+1:end);

Sets.Test_Original_Input   = Test_set(:,1:N_of_Input);
Sets.Test_Original_Output  = Test_set(:,1:N_of_Input);
Sets.Test_Processed_Input  = Input_test_processed(:,1:N_of_Input);
Sets.Test_Processed_Output = Input_test_processed(:,N_of_Input+1:end);