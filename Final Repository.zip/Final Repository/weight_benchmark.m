%% Benchmark: weighted mobile mean with exponential smoothing
function [Mean_sequence,Pers_sequence,Output_desired] = weight_benchmark(Learn_set, Test_set, options)

% Options
memory_weight = options.memory_weight; % factor that decide how fast the old data will be forget
input_size = options.input_size; % indicate how much of the dataset are inputs

% size of Learn & Test set
Learn_size = size(Learn_set);
Test_size = size(Test_set);
output_size = Test_size(2) - input_size;

% forecast deepness
days_to_forecast = floor((output_size-1)/24) + 1;

% "Training" of the mean
% A weighted average profile is extracted by processisng the Learning Set
Mean_profile = zeros(24,1);
for i=1:Learn_size(1)
    j = mod(i-1,24)+1;
    weight = min(j/10,memory_weight);
    actual_input = Learn_set(i,input_size);
    Mean_profile(j) = weight * Mean_profile(j) + (1-weight) * actual_input;
end

% "Test" of the Mean
Mean_sequence = zeros(Test_size(1),output_size);
Output_desired = zeros(Test_size(1),output_size);
for i=1:Test_size(1)
    j = mod(i-1,24)+1;
    Input_test_used = Test_set(i,input_size);
    Output_test_used = Test_set(i,input_size+1:end);

    Mean_profile_app = [Mean_profile(j+1:end);Mean_profile(1:j)];
    Mean_profile_app_2 = repmat(Mean_profile_app',1,days_to_forecast);

    Mean_sequence(i,:) = Mean_profile_app_2(1:output_size);
    Output_desired(i,:) = Output_test_used;

    actual_input = Input_test_used;
    weight = memory_weight;
    Mean_profile(j) = weight * Mean_profile(j) + (1-weight) * actual_input;
end

% WEEK SEASONAL PERSISTENCY
Data_set = [Learn_set; Test_set];
rows_indexs = (1:Test_size(1)) + Learn_size(1) -24*7;
cols_indexs = (1:output_size) + input_size;
Pers_sequence = Data_set(rows_indexs,cols_indexs);