
function [Network, Results] = Net_learn_expanded(Input, options)

% This function utilizes the MLMVN batch learning algorithm for a network
% containing 2 hidden layers and a single output layer
% This version of the function supports only continuous inputs and
% continuous output

%% Description of input parameters:
% Input - matrix of MVN inputs (N x (n+1)), where N=number of learning
% samples, n = number of inputs, the last n_of_outputs columns of this matrix represent 
% desired outputs. Each row of this matrix is a learning sample - inputs
% followed by the desired output
%
% options: struct with the followinf fields
% hidneur_num - a vector containing 2 elements: hidneur_num(1)= # of
% neurons in the 1st hidden layer, hidneur_num(2) = # of neurons in the 2nd
% hidden layer
%
% GlobalThreshold - a threshold for ang_RMSE. The learning process stops as
% soon as ang_RMSE <= GlobalThreshold holds
%
% max_iterations - max number of iterations. the code can go further if the
% validation error keep to fall down
%
% n_of_outputs - allow to identify how many of the last coloumns are to be
% considered as output
%
% val_proportion - indicate the percentage of the Learnset that it will be
% used as validation test. it start from the bottom of the matrix
%
% type - vector of 3 strings, it represent the tipe of activation function
% used in each layer. Available options: 
% - abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
% - abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
% - non-> no operation performed, log-> logaritmic norm, max-> max normalization
%
% plot_on - first enable plot of errors, second enable plot of the output
% of the layers

%%% option unzip
hidneur_num = options.hidneur_num;
GlobalThreshold = options.GlobalThreshold;
max_iterations = options.max_iterations;
n_of_outputs = options.n_of_outputs;
val_proportion = options.val_proportion;
type = options.type;
plot_on = options.plot_on;
max_norm_on = options.max_norm_on;

%% Description of output parameters:
%%% Network-> struct with the following fields:
% hidneur_weights1 - weights of all neurons from the 1st hidden layer
% hidneur_weights2 - weights of all neurons from the 2nd hidden layer
% outneur_w - weights of output neuron
% options - same as the input, saved to remember the characteristic
% max_hidden - max value of the layer output finded during training, set at 1 if <1 
%
%%% Results-> struct with the following fields
% iterations - number of iterations performed till the end of the training
% err_history - history of the error
% train_output - matrix of the output of the training set generated at the end of last iteration
% val_output - matrix of the output of the validation set generated at the end of last iteration
% des_train_output - matrix of the output of the training set desired
% des_val_output - matrix of the output of the validation set desired

%% Setup
%X = matrix of MVN inputs (N x n), where N=number of learning
%samples, n = number of input variables
N_out = n_of_outputs;
[N, m] = size(Input);
n = m-N_out; % n = # of inputs
X = Input(:,1:n); % X is a matrix of inputs

y_d = Input(:,n+1:end); % y_d is a vector-column of desired outputs

% Extraction of the # of neurons on the 1st and 2nd hidden layers
hidneur_num1 = hidneur_num(1);
hidneur_num2 = hidneur_num(2);

%%% Generation of the validation test
size_validation = fix(N*val_proportion);
size_training = N - size_validation;
use_validation = size_validation > 0;

max_iterations_app = fix(max_iterations*1.25);
err_history = zeros(2,max_iterations_app);
ang_RMSE_history = zeros(2,max_iterations_app);

%Use the clock to set the stream of random numbers
%RandStream.setDefaultStream(RandStream('mt19937ar','seed',sum(100*clock)));
RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));

%% Inizialization
% starting error
err_val_min = 10000;

%Generate random weights for the 1st hidden layer neurons:
hidneur_weights1 = zeros(n+1, hidneur_num1);

for hh = 1 : hidneur_num1

    %real part (interval -0.5 to 0.5)
    w_re = rand(n+1, 1) - 0.05;
    %imaginary part (interval -0.5 to 0.5)
    w_im = rand(n+1, 1) - 0.05;

    %Construct a weights vector, dimensions (n+1 x 1)
    hidneur_weights1(:, hh) = w_re + 1i .* w_im;

end

%Generate random weights for the 2nd hidden layer neurons:
hidneur_weights2 = zeros(hidneur_num1+1, hidneur_num2);

for hh = 1 : hidneur_num2

    %real part (interval -0.5 to 0.5)
    w_re = rand(hidneur_num1+1, 1) - 0.05;
    %imaginary part (interval -0.5 to 0.5)
    w_im = rand(hidneur_num1+1, 1) - 0.05;

    %Construct a weighting vector, dimensions (n+1 x 1)
    hidneur_weights2(:, hh) = w_re + 1i .* w_im;

end


%Generate random weights for the output neuron:
outneur_w = zeros(hidneur_num2+1, N_out);

for hh = 1 : N_out
    %real part (interval -0.5 to 0.5)
    w_re = rand(hidneur_num2+1, 1) - 0.5;
    %imaginary part (interval -0.5 to 0.5)
    w_im = rand(hidneur_num2+1, 1) - 0.5;

    %Construct a weighting vector, dimensions (n+1 x 1)
    outneur_w(:, hh) = w_re + 1i .* w_im;

end

% Inizialization best version of the weights
hidneur_weights1_best = hidneur_weights1;
hidneur_weights2_best = hidneur_weights2;
outneur_w_best = outneur_w;
max_hidden_best = [1 1 1];
%------------------------------------------------------------------------

% Counter of iterations
iterations = 0;
keep_iterate = 1;
% Counter of the learning samples with the errors
nesovpad = 1;

% GUI initiation
h = LearnStatsFig;
handles = guidata(h);

ang_RMSE = 700; % just to start a while loop

tic
err_val_old = 100000;
training_platue = 0;
platue_count = 0;
batch_changed_count = 0;

err_all_H = zeros(1,max_iterations_app);
err_val_H = zeros(1,max_iterations_app);
ang_RMSE_tra_H = zeros(1,max_iterations_app);
ang_RMSE_val_H = zeros(1,max_iterations_app);


%%% Generation of the validation and training set
val_start_index = N - size_validation + 1;
train_start_index = size_validation + 1;
X_train = X(1:size_training,:);
X_val = X(val_start_index:end,:);

znet_d = y_d(1:size_training,:);
znet_d_val = y_d(val_start_index:end,:);

% X_train = X(train_start_index:end,:);
% X_val = X(1:size_validation,:);
% 
% znet_d = y_d(train_start_index:end,:);
% znet_d_val = y_d(1:size_validation,:);

%%append a column of 1s to X from the left, yielding a (N x n+1) matrix
col_app = ones(size_training,1);
app_X = [col_app X_train];

%Construct the pseudo-inverse matrix of X
X_pinv = pinv(app_X);

if use_validation
    %append a column of 1s to X from the left
    %app_X
    col_app_val = ones(size_validation,1);
    app_X_val = [col_app_val X_val];
end

%% Start of the Training
%%% First elaboration of the Network

%%%  Compute the output of the 1st hidden neurons for all samples PRE
%%%  BackProp
hid_outmat1 = app_X * hidneur_weights1;

% 1st Hidden Layer: execution of the choose activation function
abs_hid_outmat1 = abs(hid_outmat1);
if strcmp(type(1,:),'abs')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1);
elseif strcmp(type(1,:),'log')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* log(abs_hid_outmat1+1);
elseif strcmp(type(1,:),'tan')
    hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* tanh(abs_hid_outmat1);
end

% append a column of 1s to X1 from the left
app_X1 = [col_app hid_outmat1];

%%%  Compute the output of the 2nd hidden neurons for all samples PRE
%%%  BackProp
hid_outmat2 = app_X1 * hidneur_weights2;

% 2st Hidden Layer: execution of the choose activation function
abs_hid_outmat2 = abs(hid_outmat2);
if strcmp(type(2,:),'abs')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2);
elseif strcmp(type(2,:),'log')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* log(abs_hid_outmat2+1);
elseif strcmp(type(2,:),'tan')
    hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* tanh(abs_hid_outmat2);
end

%% Loop of Learning with BackPropagation 
while (ang_RMSE >= GlobalThreshold) && keep_iterate %&& (~training_platue)
    %%% Calculation of the network error and its backpropagation
    [hid_errmat1, hid_errmat2] = ErrBackProp_extended(hid_outmat2, hidneur_weights2, outneur_w, znet_d, hidneur_num, n, abs_hid_outmat1, abs_hid_outmat2, type(3,:));
    
    % Adjust weights of hidden neurons from the 1st hidden layer
    hidneur_weights1 = HidNeuron_weightadj1(X_pinv, hidneur_weights1, hid_errmat1);
    
    %%%  Compute the output of the 1st hidden neurons for all samples POST
    %%%  BackProp
    hid_outmat1 = app_X * hidneur_weights1;
    
    % 1st Hidden Layer: execution of the choose activation function
    abs_hid_outmat1 = abs(hid_outmat1);
    if strcmp(type(1,:),'abs')
        hid_outmat1 = (hid_outmat1./abs_hid_outmat1);
    elseif strcmp(type(1,:),'log')
        hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* log(abs_hid_outmat1+1);
    elseif strcmp(type(1,:),'tan')
        hid_outmat1 = (hid_outmat1./abs_hid_outmat1) .* tanh(abs_hid_outmat1);
    end
    
    %%% Division for the max of the output to bring everything in the unit
    %%% circle
    max_hidden(1) = max(max(abs(hid_outmat1),[],"all"),1) * max_norm_on + (1-max_norm_on);
    hid_outmat1 = hid_outmat1/max_hidden(1);    

    % append a column of 1s to X1 from the left
    app_X1 = [col_app hid_outmat1];
    
    %Construct the pseudo-inverse matrix of X1
    X_pinv1 = pinv(app_X1);
        
    %Adjust weights of hidden neurons from the 2nd hidden layer
    hidneur_weights2 = HidNeuron_weightadj2(X_pinv1, hidneur_weights2, hid_errmat2);
    
    %%%  Compute the output of the 2nd hidden neurons for all samples POST
    %%%  BackProp
    hid_outmat2 = app_X1 * hidneur_weights2;
    
    % 2st Hidden Layer: execution of the choose activation function
    abs_hid_outmat2 = abs(hid_outmat2);
    if strcmp(type(2,:),'abs')
        hid_outmat2 = (hid_outmat2./abs_hid_outmat2);
    elseif strcmp(type(2,:),'log')
        hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* log(abs_hid_outmat2+1);
    elseif strcmp(type(2,:),'tan')
        hid_outmat2 = (hid_outmat2./abs_hid_outmat2) .* tanh(abs_hid_outmat2);
    end

    %%% Division for the max of the output to bring everything in the unit
    %%% circle
    max_hidden(2) = max(max(abs(hid_outmat2),[],"all"),1) * max_norm_on + (1-max_norm_on);
    hid_outmat2 = hid_outmat2/max_hidden(2);

    [outneur_w, z_outneur] = OutNeuron_weightadj(hid_outmat2, znet_d, outneur_w);

    %%%  Compute the output of the Output Layer for all samples POST
    %%%  BackProp
    % Output Layer: execution of the choose activation function
    abs_z_outneur = abs(z_outneur);
    max_z_out = max(abs(z_outneur),[],"all");
    if strcmp(type(3,:),'non')
        z_outneur = z_outneur;
    elseif strcmp(type(3,:),'abs')
        z_outneur = (z_outneur./abs_z_outneur);
    elseif strcmp(type(3,:),'log')
        z_outneur = (z_outneur./abs_z_outneur) .* log(abs_z_outneur+1);
    elseif strcmp(type(3,:),'max')
        z_outneur = (z_outneur./max_z_out);
    end

    %Compute and display learning statistics----
    iterations = iterations + 1;
    
    %% Train_error
    %%% Euclidian Error
    error_app = abs(znet_d - z_outneur);
    err_all = error_app.^2;
    err_all = sqrt(mean(err_all,2));
    err_all = mean(err_all,"all");

    %%% Angular RMSE
    ang_err = abs(angle(znet_d) - angle(z_outneur));
    if ang_err > pi
        ang_err = 2*pi - ang_err;
    end
    ang_RMSE = ang_err.^2;
    ang_RMSE = sqrt(mean(ang_RMSE,2));
    ang_RMSE = mean(ang_RMSE,"all");

    % Flags contin 1 at the positions where current_pase differs from the
    Flags = (angle(znet_d) ~= angle(z_outneur));
    % nesovpad is the number of errors over the entire learning set
    nesovpad = sum(Flags);
    
    if use_validation
        %% Processing of the Network with Validation Set as Input
        %%%  Compute the output of the 1st hidden neurons for all samples POST
        %%%  BackProp
        hid_outmat1_val = app_X_val * hidneur_weights1;
    
        % 1st Hidden Layer: execution of the choose activation function
        abs_hid_outmat1_val = abs(hid_outmat1_val);
        if strcmp(type(1,:),'abs')
            hid_outmat1_val = (hid_outmat1_val./abs_hid_outmat1_val);
        elseif strcmp(type(1,:),'log')
            hid_outmat1_val = (hid_outmat1_val./abs_hid_outmat1_val) .* log(abs_hid_outmat1_val+1);
        elseif strcmp(type(1,:),'tan')
            hid_outmat1_val = (hid_outmat1_val./abs_hid_outmat1_val) .* tanh(abs_hid_outmat1_val);
        end

        %%% Division for the max of the output to bring everything in the unit
        %%% circle
        hid_outmat1_val = hid_outmat1_val/max_hidden(1);

        % append a column of 1s to X1 from the left
        app_X1_val = [col_app_val hid_outmat1_val];
        
        %%%  Compute the output of the 2nd hidden neurons for all samples POST
        %%%  BackProp
        hid_outmat2_val = app_X1_val * hidneur_weights2;
        
        % 2st Hidden Layer: execution of the choose activation function
        abs_hid_outmat2_val = abs(hid_outmat2_val);
        if strcmp(type(2,:),'abs')
            hid_outmat2_val = (hid_outmat2_val./abs_hid_outmat2_val);
        elseif strcmp(type(2,:),'log')
            hid_outmat2_val = (hid_outmat2_val./abs_hid_outmat2_val) .* log(abs_hid_outmat2_val+1);
        elseif strcmp(type(2,:),'tan')
            hid_outmat2_val = (hid_outmat2_val./abs_hid_outmat2_val) .* tanh(abs_hid_outmat2_val);
        end

        %%% Division for the max of the output to bring everything in the unit
        %%% circle
        hid_outmat2_val = hid_outmat2_val/max_hidden(2);

        %append a column of 1s to hid_outmat
        hid_outmat2_val = [col_app_val hid_outmat2_val];
        
        %%%  Compute the output of the Output Layer for all samples POST
        %%%  BackProp
        z_outneur_val = hid_outmat2_val * outneur_w;

        % Output Layer: execution of the choose activation function
        abs_z_outneur_val = abs(z_outneur_val);
        if strcmp(type(3,:),'non')
            z_outneur_val = z_outneur_val;
        elseif strcmp(type(3,:),'abs')
            z_outneur_val = (z_outneur_val./abs_z_outneur_val);    
        elseif strcmp(type(3,:),'log')
            z_outneur_val = (z_outneur_val./abs_z_outneur_val) .* log(abs_z_outneur_val+1);
        elseif strcmp(type(3,:),'max')
            z_outneur_val = (z_outneur_val./max_z_out);
        end

        %% Validation Error
        %%% Euclidian Error
        err_app_val = abs(znet_d_val - z_outneur_val);
        err_val = err_app_val.^2;
        err_val = sqrt(mean(err_val,2));
        err_val = mean(err_val,"all");
    
        %%% Angular RMSE
        ang_err_val = abs(angle(znet_d_val) - angle(z_outneur_val));
        if ang_err_val > pi
            ang_err_val = 2*pi - ang_err_val;
        end
        ang_RMSE_val = ang_err_val.^2;
        ang_RMSE_val = sqrt(mean(ang_RMSE_val,2));
        ang_RMSE_val = mean(ang_RMSE_val,"all");

        % for a zooming plot
        y_max = 50*abs(err_val);
    else
        err_val = 0;
        y_max = 10*abs(err_all);
        ang_RMSE_val = 0;
    end

    %%% err_val is keep decreasing?
    err_val_decrising = err_val_old  > err_val;
    %%% aggiornamento err_val_old
    err_val_old = err_val;

    %%% saving of the best wheights
    if abs(err_val) <= abs(err_val_min) 
        hidneur_weights1_best = hidneur_weights1;
        hidneur_weights2_best = hidneur_weights2;
        outneur_w_best = outneur_w;
        max_hidden_best = max_hidden;
        err_val_min = err_val;
    end

    %% Display
    %%% Errors History
    if plot_on(1)
        [err_history, ang_RMSE_history] = error_history_plot(err_all, err_val, err_val_min, ang_RMSE, ang_RMSE_val, err_history, ang_RMSE_history, iterations, 1, y_max);
    end

    %%% Display Hidden Layer Status
    if plot_on(2) && mod(iterations,10) == 1
        [output_info] = hidden_neuron_output_plot(X_train, hid_outmat1, hid_outmat2, z_outneur, znet_d, 2, "Train Set");
    end

    error_string = sprintf('train:%d val:%d val_min:%d', abs(err_all), abs(err_val), abs(err_val_min));
    %Display the statistic in a separate figure
    set(handles.IterLabel, 'String', num2str(iterations));
    set(handles.ErrLabel, 'String', error_string);
%     disp(error_string)
    set(handles.NesovpadLabel, 'String', num2str(nesovpad));
    set(handles.AngRMSELabel, 'String', num2str(ang_RMSE));
    guidata(h, handles);
    drawnow;
    
    
    %Build a list of statistic (for all iterations)
    %verr_all(iterations) = err_all;
    %vang_RMSE(iterations) = ang_RMSE;
    %vnesovpad(iterations) = nesovpad;
    %----

    %% Condition to keep iterate
    
    keep_iterate = ((iterations <= max_iterations) || (err_val_decrising)) && (iterations <= max_iterations_app);
end

toc

close(h);

disp(' ');
disp(['Iteration: ', num2str(iterations)]);
disp(['Squared norm of error ', num2str(err_all)]);
disp(['Nesovpad: ', num2str(nesovpad)]);
disp(['Ang RMSE: ', num2str(ang_RMSE)]);

disp('Learning completed!');

%% Output generation

% Network
Network.hidneur_weights1 = hidneur_weights1_best;
Network.hidneur_weights2 = hidneur_weights2_best;
Network.outneur_w = outneur_w_best;
Network.max_hidden = max_hidden_best;
Network.option = options;

% Results
Results.iterations = iterations;
Results.err_history = err_history;
Results.train_output = z_outneur;
Results.val_output = z_outneur_val;
Results.des_train_output = znet_d;
Results.des_val_output = znet_d_val;