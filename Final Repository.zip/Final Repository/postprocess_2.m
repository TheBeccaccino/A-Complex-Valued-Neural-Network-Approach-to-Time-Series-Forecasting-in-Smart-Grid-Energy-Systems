function [real_output_used] = postprocess_2(actual_output, N_of_Output, max_input_norm)
e = 2.72;
N_sequences = size(actual_output,1);
% actual_output(:,37) = zeros(N_sequences,1);
actual_output_app = actual_output * N_of_Output;

real_output_used = ifft(actual_output_app');

real_output_used = abs(real_output_used);

real_output_used = (real_output_used') .* max_input_norm;

real_output_used = e.^(real_output_used) - 1;
