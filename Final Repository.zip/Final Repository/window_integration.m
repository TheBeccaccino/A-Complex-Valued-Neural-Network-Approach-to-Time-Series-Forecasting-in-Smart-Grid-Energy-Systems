function [window_sum] = window_integration(array, window_extension)
size_array = size(array);
array_app = zeros(size_array(1),size_array(2) + 2*window_extension);

start_index = window_extension + 1;
stop_index = window_extension + size_array(2);
% start_index = 1;
% stop_index = size_array(2);

array_app(:, start_index:stop_index) = array;

window_sum = zeros(size_array);
for w = 1:(1+2*window_extension)
    start_index = w;
    stop_index = w + size_array(2) - 1;
    
    window_sum = window_sum + array_app(:, start_index:stop_index);
end