%% Preprocessing with FFT
function [Gen_Set_post] = postprocess_with_FFT_2(Gen_Set, N_of_Output, N_of_Output_red, Offset)
% size Set
Gen_Set_size = size(Gen_Set);

% Inizializzazione del set post
Gen_Set_post = zeros(Gen_Set_size(1), N_of_Output);
Gen_Set_post(:,1) = Offset;

%% Mirroring Seq
Gen_Set_conj = conj(Gen_Set);

%% Filling of set post
start_indx = 2;
stop_indx = N_of_Output_red + 1;
Gen_Set_post(:,start_indx:stop_indx) = Gen_Set;

%%% conj
start_indx_conj = N_of_Output;
stop_indx_conj = N_of_Output_red + 1;
Gen_Set_post(:,start_indx_conj:-1:stop_indx_conj) = Gen_Set_conj; 

a=1;
