%% Preprocessing with FFT
function [Input_learn_processed, Input_test_processed, Input_learn_offset, Input_test_offset, N_of_Input_red, N_of_Output_red, Sets] = preprocess_with_FFT_2(Learn_set, Test_set, N_of_Input, N_of_Output, Sets)
Learn_size = size(Learn_set,1);
Test_size = size(Test_set,1);

% Estrazione Input learn offset
Input_learn_offset = Learn_set(:,1);

% Estrazione Input test offset
Input_test_offset = Test_set(:,1);

%% Riduzione Input
Learn_Input_app = Learn_set(:,2:N_of_Input);
Test_Input_app = Test_set(:,2:N_of_Input);

%%% Size Reduction
N_of_Input_red = ceil((N_of_Input-1)/2);%N_of_Input-1;%
Learn_Input_app_2 = Learn_Input_app(:,1:N_of_Input_red);
Test_Input_app_2 = Test_Input_app(:,1:N_of_Input_red);
  
%% Riduzione Output
Learn_Output_app = Learn_set(:,end-N_of_Output+2:end);
Test_Output_app = Test_set(:,end-N_of_Output+2:end);

%%% Size Reduction
N_of_Output_red = ceil((N_of_Input-1)/2);
Learn_Output_app_2 = Learn_Output_app(:,1:N_of_Output_red);
Test_Output_app_2 = Test_Output_app(:,1:N_of_Output_red);
 
%% Output
% Generazione Sets
Input_learn_processed = [Learn_Input_app_2, Learn_Output_app_2];
Input_test_processed = [Test_Input_app_2, Test_Output_app_2];

% Sets
Sets.Learn_Processed_Input  = Learn_Input_app_2;
Sets.Learn_Processed_Output = Learn_Output_app_2;

Sets.Test_Processed_Input  = Test_Input_app_2;
Sets.Test_Processed_Output = Test_Output_app_2;
