%% Metric Evaluation
function [Metrics] = metrics_evaluation (Generated_Seq, Desired_Seq)

%% RMSE 
SE = (Generated_Seq - Desired_Seq).^2;
MSE = mean(SE,"all");

% mean of the sequence
Metrics.RMSE_mean = sqrt(MSE);

% distributed along the sequence
MSE_h = mean(SE,1);
Metrics.RMSE_h = sqrt(MSE_h);

%% MAPE 
check = Desired_Seq == 0;
check_1 = sum(check,2) > 0;
Generated_Seq_app = Generated_Seq(~check_1,:);
Desired_Seq_app = Desired_Seq(~check_1,:);
APE = abs(Generated_Seq_app - Desired_Seq_app)./Desired_Seq_app;

% mean of the sequence
Metrics.MAPE_mean = mean(APE,"all");

% distributed along the sequence
Metrics.MAPE_h = mean(APE,1);

%% BIAS
% mean of the sequence
Metrics.BIAS_mean = mean(Generated_Seq - Desired_Seq,"all");
% distributed along the sequence
Metrics.BIAS_h = mean(Generated_Seq - Desired_Seq,1);

%% Integral Evaluation
Generated_integral = cumsum(Generated_Seq,2);
Desired_integral = cumsum(Desired_Seq,2);

% mean of the sequence
Metrics.RMSE_Int = sqrt(mean((Generated_integral - Desired_integral).^2,"all"));

% distributed along the sequence
Metrics.RMSE_Int_h = (sqrt(mean((Generated_integral - Desired_integral).^2,1)))';

%% Derivate Evaluation
Generated_derivate = diff(Generated_Seq,1,2);
Desired_derivate = diff(Desired_Seq,1,2);

% mean of the sequence
Metrics.RMSE_Der = sqrt(mean((Generated_derivate - Desired_derivate).^2,"all"));

% distributed along the sequence
Metrics.RMSE_Der_h = (sqrt(mean((Generated_derivate - Desired_derivate).^2,1)))';

%% Window Integral Evaluation
%%% Integral Window
[real_output_window_sum] = window_integration(Generated_Seq, 3);
[real_output_des_window_sum] = window_integration(Desired_Seq, 3);

%%%%%% RMSE
Metrics.RMSE_Win = sqrt(mean((real_output_window_sum - real_output_des_window_sum).^2,"all"));
Metrics.RMSE_Win_h = (sqrt(mean((real_output_window_sum - real_output_des_window_sum).^2,1)))';

%%%%%% MAPE
error_array = (real_output_window_sum - real_output_des_window_sum);
Metrics.MAPE_Win = mean(abs(error_array./real_output_des_window_sum),"all");
Metrics.MAPE_Win_h = mean(abs(error_array./real_output_des_window_sum),1)';  

%% ERR
ERROR = (Generated_Seq - Desired_Seq);
[n_seq, n_step] = size(ERROR);
for i = (n_step-1):-1:1
    start_indx = i+1;
    stop_index = n_seq - i;
    ER = abs(ERROR(1:stop_index,start_indx)) - abs(ERROR(start_indx:end,1));
    ERR_matrix(start_indx:n_seq,i) = ER./abs(ERROR(1:stop_index,start_indx));
    ER_rel = ER./abs(ERROR(1:stop_index,start_indx));
    ERR_matrix(start_indx:n_seq,i) = ER_rel;
    ERR(:,i) = mean(ER,1);
end
% ER = abs(ERROR(2:end,1:(end-1)) - ERROR(1:(end-1),2:end));
% ERR_app = ER;% ./ abs(ERROR(1:(end-1),2:end));
% ERR = mean(ERR_app,1);
Metrics.ERR = ERR;




