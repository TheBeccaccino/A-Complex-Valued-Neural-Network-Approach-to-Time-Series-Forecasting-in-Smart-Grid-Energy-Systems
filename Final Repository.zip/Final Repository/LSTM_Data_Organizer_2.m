function [LSTM_X_set, LSTM_Y_set, X_set_app, Y_set_app] = LSTM_Data_Organizer(LSTM_set, N_Input, N_Output, N_Features)

numSeq = size(LSTM_set,1);
LSTM_set = permute(LSTM_set,[2 3 1]);

X_set_app = LSTM_set(1:N_Input,:,  :);
test_indx = (1:N_Output) + N_Input;
Y_set_app = LSTM_set(test_indx, :, :);

for i = numSeq:-1:1
    % X: 2 feature x 10 time steps
    % data(idx,:) è [10 x 2] → trasposta diventa [2 x 10]
    LSTM_X_set{i} = X_set_app(:,:,i);

    % Y: predizione del time step successivo (un singolo valore)
    LSTM_Y_set{i} = Y_set_app(:,:,i);
end        

LSTM_X_set = LSTM_X_set';
LSTM_Y_set = LSTM_Y_set';

X_set_app = permute(X_set_app,[2 1 3]);
Y_set_app = permute(Y_set_app,[2 1 3]);































a=1;