function [a] = comparison_plot(MLMVN_output, LSTM_output, Bench_sequence, Desired_output, t, fig_N, p, Overlap)
            figure(fig_N)
            sgtitle(t) % 

            start_indx = Overlap+1;

            plot(MLMVN_output(p,start_indx:end),'.-')
            title("Output of the Network: Real Postprocessed Output")
            hold on
            plot(LSTM_output(p,start_indx:end),'.-')
            plot(Bench_sequence(p,start_indx:end),'.-')
            plot(Desired_output(p,start_indx:end),'.-')
            grid on
            legend('MLMVN output', 'LSTM output', 'Bench','Desired output')
            hold off

            a=1;

