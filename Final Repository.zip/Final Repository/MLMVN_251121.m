%% CLeared Code for MLMVN applied to the household load forecasting in case of only active power available
% Possibility to choose between unit circle normalization of FFT 
clear
% close all

%%

%% Setup
e = 2.72;
load Australian_dataset_load.mat    % Load of Ausgrid dataset
load tubitex_dataset.mat
u = 35;  % Choose of the user in the dataset
E_load_h_all;
% We can choose the size of the Input and output sequences. The code can
% already do different test for different combination to compare the performances if the size arrays have more than one option
Input_size_array = 72; %[1,6,12,24,48,72];  % Experiment performed with 72 Input sequence
n_input_size = size(Input_size_array,2);
Output_size_array = 72; %[1,6,12,24,48,72]; % Experiment performed with 72 Output sequence
n_output_size = size(Output_size_array,2);

max_input_size = max(Input_size_array,[],"all");
max_output_size = max(Output_size_array,[],"all");

% Data_size = size(tubitex_cmplx_1h(:,u),1);
Data_size = size(E_load_h_all(:,u),1);
N_of_days = ceil(Data_size/24);
N_of_weeks = ceil(N_of_days/7);
day_indexes = repmat((1:7),24,N_of_weeks);
hour_indexes = reshape(day_indexes(:,1:N_of_days),[],1);

N_of_set = Data_size - max_input_size - max_output_size; % Number of possible set of data to be divided in train and test

% Choose of the sector in which normilize the data in caso of unit circle
% normalization, In this case O1 ~ 45° and O2 ~ 30°
sector_unit = pi/12; %rad
O1 = 24*sector_unit;%(2+1) * sector_unit; %ampiezza settore angolare | 38°
O2 = 0;%(3-1) * sector_unit; %ampiezza offset             | 68°
O1_list = O1; %[12 10 8 6 4 2.5 2.3] * sector_unit;

%choose of the type of elaboration of the data
Elab_type = 3; % 0-> norm on unit circle, 1-> FFT

% Define the architecture of your network. To this particular problem it
% seems that 75 neuron in the first layer and 100 in the second is the best
% configuration
hiddenLayerSize_1_list = 75;%75; %[10 10 20 30 70 75];% Number of neurons in the first hidden layer
hiddenLayerSize_2_list = 100;% [70 70 80 80 90 100];% Number of neurons in the second hidden layer
%number of epochs
n_epoch = 800;
% chose of the activation functions of each layer
fun_h1 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
fun_h2 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
fun_out = 'log'; %options: non-> no operation performed, log-> logaritmic norm, max-> max normalization

type(1,:) = fun_h1;
type(2,:) = fun_h2;
type(3,:) = fun_out;

% plot_on
plot_on = 0;

% Sets parameters
n_of_train_months = 3;
n_of_months_in_daset = 8;
max_m = n_of_months_in_daset - n_of_train_months;
validation_size = 0.10;

Train_size = n_of_train_months*30*24;%fix(Data_size*0.1); 
Validation_size = fix(Train_size * validation_size);

Learn_size =Train_size; %Validation_size + 
Test_size = 20*24;%Learn_size;%

% Set Generation: In this section the Learning and Test set are extracted from the Data set
% Data = real(tubitex_cmplx_1h(:,u));
Data = real(E_load_h_all(:,u));
Overlap = 0;
for d = N_of_set:-1:1
    input_index  = (1:max_input_size)  + d-1;
    output_index = (1:max_output_size) + d-1 + max_input_size - Overlap;
    set_Data(d,:)       = [Data(input_index); Data(output_index)];
    set_Data_index(d,:) = [hour_indexes(input_index); hour_indexes(output_index)];
end

%% Start of the loop, we can decide to performe multiple experiment in which we shift the chosed sets
for max_m:-1:1 %m = 1%
    %% Ordered Generation of Learn & Test set
    % dimension 1
    offset = (m-1)*30*24;
    stop_indx = Learn_size + Test_size;

    % dimension 2
    start_indx_2 = 1;
    stop_indx_2 = max_input_size + max_output_size;

    % Learn and Test set used
    Learn_set = set_Data(1+offset:Learn_size+offset,:);
    Test_set  = set_Data(Learn_size+1+offset:stop_indx+offset,:);
    Learn_set_index = set_Data_index(1+offset:Learn_size+offset,:);
    Test_set_index  = set_Data_index(Learn_size+1+offset:stop_indx+offset,:);

    Output_test_original = set_Data(Learn_size+1+offset:stop_indx+offset,max_input_size+1:max_input_size+max_output_size);
    Input_test_plot = Test_set;


    %% Benchmark: weighted mobile mean with exponential smoothing
    %%% Solution to forecast that not require neural networks, used as benchmark comparison
    options_wbench.memory_weight = 0.95;
    options_wbench.input_size = max_input_size;
    [Mean_sequence,Pers_sequence,Output_desired] = weight_benchmark(Learn_set, Test_set, options_wbench);

    %% Code for the different Input-Output size combination
    for Input_size_indx = n_input_size:-1:1
    for Output_size_indx = n_output_size:-1:1

        %% Setup 
        hiddenLayerSize_1 = hiddenLayerSize_1_list(Input_size_indx);
        hiddenLayerSize_2 = hiddenLayerSize_2_list(Input_size_indx);
        hidsize = [hiddenLayerSize_1 hiddenLayerSize_2];

        N_of_Input = Input_size_array(Input_size_indx);
        N_of_Output = Output_size_array(Output_size_indx);
        N_of_Input_app = N_of_Input;
        N_of_Output_app = N_of_Output;
        
        disp([m, N_of_Input, N_of_Output, hidsize, O1])

        %%% dimension of the set
        % dimensione 1
        offset = (m-1)*30*24;
        stop_indx = Learn_size + Test_size;
    
        % dimensione 2
        start_indx_2 = max_input_size - N_of_Input + 1;
        stop_indx_2 = max_input_size + N_of_Output;

        %% Preprocessing
        switch Elab_type
            case 0 %% Normalization on Unit Circle
            [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_unit_circle(Learn_set, Test_set, O1, O2, start_indx_2, stop_indx_2, N_of_Input);

            case 1 %% Use of FFT    
            [Input_learn_processed, Input_test_processed, max_matrix, ~,~, Sets] = preprocess_with_FFT(Learn_set, Test_set, N_of_Input, N_of_Output, start_indx_2, stop_indx_2);
            max_input_learn = max_matrix.max_input_learn;
            max_input_test = max_matrix.max_input_test;

            case 2 %% Use of FFT and reduction of the size   
            [Input_learn_processed, Input_test_processed, max_matrix, ~,~, Sets] = preprocess_with_FFT(Learn_set, Test_set, N_of_Input, N_of_Output, start_indx_2, stop_indx_2);
            [Input_learn_processed, Input_test_processed, Input_learn_offset, Input_test_offset, N_of_Input_red, N_of_Output_red, Sets] = preprocess_with_FFT_2(Input_learn_processed, Input_test_processed, N_of_Input, N_of_Output, Sets); 
            N_of_Input_app = N_of_Input_red;
            N_of_Output_app = N_of_Output_red;
            max_input_learn = max_matrix.max_input_learn;
            max_input_test = max_matrix.max_input_test;

            case 3 %% Normalization on Unit Circle + Days 
            [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_day_of_the_week(Learn_set, Test_set, O1, O2, start_indx_2, stop_indx_2, Learn_set_index, Test_set_index, N_of_Input);
        end

        Progr_Learning_MVN = Input_learn_processed;
        Progr_Testing_MVN = Input_test_processed;
        t2 = 'Input Processing Example';
        input_complex_plot(Sets.Learn_Original_Input, Sets.Learn_Processed_Input, t2, 98, 1);

        %% Training Rete Neurale
        % The Network whant a complex series of data whit every example
        % represented by a row. Each row have to be composed by N_of_Input
        % element followed by more N_of_Output 

        Progr_Learning_MVN_used = Progr_Learning_MVN;

        options_learn.hidneur_num = hidsize;
        options_learn.GlobalThreshold = 0.004;
        options_learn.max_iterations = n_epoch;
        options_learn.n_of_outputs = N_of_Output_app;
        options_learn.val_proportion = validation_size;
        options_learn.type = type;
        options_learn.plot_on = [0 1];
        options_learn.max_norm_on = 1;

        [Network, Learn_Results] = Net_learn_expanded(Progr_Learning_MVN_used, options_learn);

        % %% Post Training Elaboration
        % switch Elab_type
        %     case 0 %% Normalization on Unit Circle
        % 
        %     case 1 %% Use of FFT 
        %         fig1_N = 30;
        %         fig2_N = 31;
        %         [errors] = Post_training_process(Learn_Results, N_of_Input, N_of_Output, max_input_learn, fig1_N, fig2_N, N_of_Output_red, Input_learn_offset);
        % 
        %      case 2 %% Use of FFT 
        %         fig1_N = 30;
        %         fig2_N = 31;
        %         [errors] = Post_training_process_FFT2(Learn_Results, N_of_Input, N_of_Output, max_input_learn, fig1_N, fig2_N, N_of_Output_red, Input_learn_offset); 
        % 
        %     case 3 %% Week days
        % end

        %% Test Rete Neurale
        Progr_Testing_MVN_used = Progr_Testing_MVN;
        [Test_Results] = Net_test_expanded(Progr_Testing_MVN_used, Network);

        %% Post Test Elaboration
        switch Elab_type
            case 0 %% Normalization on Unit Circle
                % Parameters
                Log_Norm = parameters.Log_Norm;
                Log_min = parameters.Log_Min;
                Log_Offset = parameters.Log_Offset;
                % Test results
                test_output = Test_Results.test_output;

                test_output_used = mod(angle(test_output), 2*pi);
                real_output_used_1 = ((test_output_used - Log_Offset)/Log_Norm) + Log_min;
                real_output_used = (e.^real_output_used_1 -1);

            case 1 %% Use of FFT 
                test_output = Test_Results.test_output;
                des_test_output = Test_Results.des_test_output;
%                 [test_output] = postprocess_with_FFT_2(test_output, N_of_Output, N_of_Output_red, Input_test_offset);
%                 [des_test_output] = postprocess_with_FFT_2(des_test_output, N_of_Output, N_of_Output_red, Input_test_offset);                
                % mean_rho_val_error = errors.val_pre;
                max_input_test_used = max_input_test(:,N_of_Input+1:end);
                test_output_used = test_output;% + repmat(mean_rho_val_error,Test_size,1);
%                 actual_output_used(:,1) = Input_test_offset;
                
                [real_output_used] = postprocess_2(test_output_used, N_of_Output, max_input_test_used);
%                 real_output_used = real_output_used - repmat(mean_rho_val_error,Test_size,1);

            case 2 %% Use of FFT 2 
                test_output = Test_Results.test_output;
                des_test_output = Test_Results.des_test_output;
                [test_output] = postprocess_with_FFT_2(test_output, N_of_Output, N_of_Output_red, Input_test_offset);
                [des_test_output] = postprocess_with_FFT_2(des_test_output, N_of_Output, N_of_Output_red, Input_test_offset);                
                % mean_rho_val_error = errors.val_pre;
                max_input_test_used = max_input_test(:,N_of_Input+1:end);
                test_output_used = test_output;% + repmat(mean_rho_val_error,Test_size,1);
                actual_output_used(:,1) = Input_test_offset;
                
                [real_output_used] = postprocess_2(test_output_used, N_of_Output, max_input_test_used);
                % real_output_used = real_output_used - repmat(mean_rho_val_error,Test_size,1);

            case 3 %% Weekdays
                a=1;
                test_output = Test_Results.test_output;
                des_test_output = Test_Results.des_test_output;
                [real_output_used, index_result] = postprocess_day_of_the_week(test_output, parameters, O1, O2);
        end

        size_output = size(real_output_used);
        real_output = real_output_used;%
        real_desired_output = Output_test_original(:,1:size_output(2));
        
        
        

        %% Benchmark 2:LSTM
        %%% 
        Power_train_LSTM = Learn_set(:,start_indx_2:stop_indx_2);
        Power_test_LSTM = Test_set(:,start_indx_2:stop_indx_2); 
        % 
        Power_train_LSTM = log(Power_train_LSTM + 1);
        Power_test_LSTM  = log(Power_test_LSTM + 1);

        Max_train = max(Power_train_LSTM(:, 1:N_of_Input),[],"all");

        Power_norm_train_LSTM = Power_train_LSTM./Max_train;
        Power_norm_test_LSTM  = Power_test_LSTM ./Max_train;


        sector = 2*pi/7;

        % Input_train_LSTM = cat(3, Power_norm_train_LSTM);
        % Input_test_LSTM  = cat(3, Power_norm_test_LSTM);
        Input_train_LSTM = cat(3, Power_norm_train_LSTM, sin(Learn_set_index*sector), cos(Learn_set_index*sector));
        Input_test_LSTM  = cat(3, Power_norm_test_LSTM, sin(Test_set_index*sector), cos(Test_set_index*sector));  

        
        numFeatures = N_of_Input;
        numHiddenUnits = 40;
        numResponses = N_of_Output;       

        % [x_train_app, t_train_app] = LSTM_Data_Organizer(Input_train_LSTM, N_of_Input, N_of_Output, numFeatures);
        % [x_test_app, t_test_app]   = LSTM_Data_Organizer(Input_test_LSTM, N_of_Input, N_of_Output, numFeatures);
        [x_train_app, t_train_app] = LSTM_Data_Organizer_2(Input_train_LSTM, N_of_Input, N_of_Output, numFeatures);
        [x_test_app, t_test_app]   = LSTM_Data_Organizer_2(Input_test_LSTM, N_of_Input, N_of_Output, numFeatures);


        weights = [(11:-2:3), 2*ones(1,15), ones(1,N_of_Output-Overlap -20)];
        % myLoss = weightedSeqRegressionLayer(weights, "weightedMSE");
        %%% Network Layers
        layers = [ ...
            sequenceInputLayer(numFeatures, Name="sequenceinput")
            lstmLayer(numHiddenUnits, OutputMode="sequence", Name="lstm")
            fullyConnectedLayer(numFeatures, Name="fc")
            regressionLayer
            % weightedSeqRegressionLayer(weights, "weightedMSE")
            ];
        % %            
            % 

        maxEpochs = 200;
        miniBatchSize = 64;
        valFrequency = 10;
        valPerc = 0.05;
        lossFcn = 'mse';
        [x_train_app, t_train_app, x_val_app, t_val_app] = validation_split(x_train_app, t_train_app, valPerc);


        options = trainingOptions('adam', ...
        'MaxEpochs',maxEpochs, ...
        'MiniBatchSize',miniBatchSize, ...
        'InitialLearnRate',0.001, ...
        'GradientThreshold',10, ...
        'Shuffle','every-epoch', ...
        'Plots','training-progress',... 
        'ValidationData',{x_val_app, t_val_app}, ...      % <-- validation set
        'ValidationFrequency',valFrequency, ...           % ogni quanto valutare
        'ValidationPatience',10, ...                      % quante volte senza migliorare prima di fermarsi
        'OutputNetwork','best-validation', ...       % prendi la rete col miglior val loss
        'L2Regularization',1e-4, ...
        'Verbose',0);%                   
    
        net = trainNetwork(x_train_app,t_train_app,layers,options);
         % net = trainnet(x_train_app,t_train_app,layers,lossFcn,options);

        y_test_app = predict(net,x_test_app,'MiniBatchSize',64);

        % [y_test_org] = LSTM_Output_Organizer(y_test_app);
        % [t_test_org] = LSTM_Output_Organizer(t_test_app);
        [y_test_org] = LSTM_Output_Organizer_2(y_test_app);
        [t_test_org] = LSTM_Output_Organizer_2(t_test_app);

        Power_norm_y_test = y_test_org(:,:,1);
        Power_norm_t_test = t_test_org(:,:,1);

        Power_y_test = Power_norm_y_test * Max_train;
        Power_t_test = Power_norm_t_test * Max_train;

        Power_y_test = exp(Power_y_test) - 1;
        Power_t_test = exp(Power_t_test) - 1;

        %% Metrics 

        %%% Metrics Evaluation
        [Metrics_Bench(m)] = metrics_evaluation (Mean_sequence, Output_desired);
        [Metrics_Pers(m)] = metrics_evaluation (Pers_sequence, Output_desired);
        [Metrics_Test] = metrics_evaluation (real_output, real_desired_output);
        [Metrics_LSTM] = metrics_evaluation (Power_y_test, Power_t_test);
   
        %%% RMSE
        RMSE_Bench(m) = Metrics_Bench(m).RMSE_mean;
        RMSE_Bench_h(m,:) = Metrics_Bench(m).RMSE_h;
    
        RMSE_Pers(m) = Metrics_Pers(m).RMSE_mean;
        RMSE_Pers_h(m,:) = Metrics_Pers(m).RMSE_h;

        RMSE_matrix(Output_size_indx,Input_size_indx,m) = Metrics_Test.RMSE_mean;
        RMSE_matrix_h(:,Output_size_indx,Input_size_indx,m) = Metrics_Test.RMSE_h;

        LSTM_RMSE_matrix(Output_size_indx,Input_size_indx,m)     = Metrics_LSTM.RMSE_mean;
        LSTM_RMSE_matrix_h(:,Output_size_indx,Input_size_indx,m) = Metrics_LSTM.RMSE_h;

        %%% ERR
        Bench_ERR = Metrics_Bench.ERR;
        Pers_ERR = Metrics_Pers.ERR;
        MLMVN_ERR = Metrics_Test.ERR;
        LSTM_ERR = Metrics_LSTM.ERR;


        %% Plot
        figure(10 + Elab_type)
        subplot(1,2,1)
        plot(real(RMSE_matrix_h(:,Output_size_indx,Input_size_indx,m)),'.-')
        hold on
        plot(real(LSTM_RMSE_matrix_h(:,Output_size_indx,Input_size_indx,m)),'.-')
        plot(RMSE_Pers_h(m,:),'.-')
        hold off
        grid on
        title('RMSE Comparison')
        legend("MLMVN", "LSTM", "Bench")

        subplot(1,2,2)
        plot(MLMVN_ERR,'.-')
        hold on
        plot(LSTM_ERR,'.-')
        plot(Bench_ERR,'.-')
        plot(Pers_ERR,'.-')
        hold off
        grid on
        title('ERR Comparison')
        legend("MLMVN", "LSTM", "Bench", 'Pers')

        %% Plots
        t = 'Test result example';
        t1 = 'Result_comparison';
%         test_output = test_output;
%         des_test_output = Test_Results.des_test_output;

        for p = 1:Test_size
            [a] = fft_plot(real_desired_output, real_output, des_test_output, test_output, t, 6, p);
            comparison_plot2(real_output, Power_y_test, Pers_sequence, real_desired_output, t1, 7, p, Overlap);
            pause(0.2)
        end

    end
    end
end