%% CLeared Code for MLMVN applied to the household load forecasting in case of only active power available
% Possibility to choose between unit circle normalization of FFT 
clear
% close all

%%

%% Setup
e = 2.72;
load Australian_dataset_load.mat    % Load of Ausgrid dataset
load tubitex_dataset.mat

%% Choice of the profile and of the elaboration type
u = 35;  % Choose of the user in the dataset
%choose of the type of elaboration of the data
Elab_type = 1; % 0-> norm on unit circle, 1-> FFT, 2-> Short FFT, 3-> Day of the week

for u = 35%127:-1:1
    for Elab_type = 1%3:-1:0
        
        %% Preliminary elaboration
        E_load_h_all;
        % We can choose the size of the Input and output sequences. The code can
        % already do different test for different combination to compare the performances if the size arrays have more than one option
        Input_size_array = 72; %[1,6,12,24,48,72];  % Experiment performed with 72 Input sequence
        n_input_size = size(Input_size_array,2);
        Output_size_array = 72; %[1,6,12,24,48,72]; % Experiment performed with 72 Output sequence
        n_output_size = size(Output_size_array,2);
        
        max_input_size = max(Input_size_array,[],"all");
        max_output_size = max(Output_size_array,[],"all");
        
        % Data_size = size(tubitex_cmplx_1h(:,u),1);
        Data_size = size(E_load_h_all,1);
        N_of_days = ceil(Data_size/24);
        N_of_weeks = ceil(N_of_days/7);
        day_indexes = repmat((1:7),24,N_of_weeks);
        hour_indexes = reshape(day_indexes(:,1:N_of_days),[],1);
        
        N_of_set = Data_size - max_input_size - max_output_size; % Number of possible set of data to be divided in train and test
        
        % Choose of the sector in which normilize the data in caso of unit circle
        % normalization, In this case O1 ~ 45° and O2 ~ 30°
        sector_unit = pi/12; %rad
        O1 = 24*sector_unit;%(2+1) * sector_unit; %ampiezza settore angolare | 38°
        O2 = 0;%(3-1) * sector_unit; %ampiezza offset             | 68°
        O1_list = O1; %[12 10 8 6 4 2.5 2.3] * sector_unit;
        
        %choose of the type of elaboration of the data
        % Elab_type = 3; % 0-> norm on unit circle, 1-> FFT, 2-> Short FFT, 3-> Day of the week
        
        % Define the architecture of your network. To this particular problem it
        % seems that 75 neuron in the first layer and 100 in the second is the best
        % configuration
        hiddenLayerSize_1_list = 75;%75; %[10 10 20 30 70 75];% Number of neurons in the first hidden layer
        hiddenLayerSize_2_list = 100;% [70 70 80 80 90 100];% Number of neurons in the second hidden layer
        %number of epochs
        n_epoch = 800;
        % chose of the activation functions of each layer
        fun_h1 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
        fun_h2 = 'log'; %options: abs-> norm on unit circle, log-> logaritmic norm, tan-> tanhnorm
        fun_out = 'log'; %options: non-> no operation performed, log-> logaritmic norm, max-> max normalization
        
        type(1,:) = fun_h1;
        type(2,:) = fun_h2;
        type(3,:) = fun_out;
        
        % plot_on
        plot_on = 0;
        
        % Sets parameters
        n_of_train_months = 3;
        n_of_months_in_daset = 8;
        max_m = n_of_months_in_daset - n_of_train_months;
        validation_size = 0.10;
        
        Train_size = n_of_train_months*30*24;%fix(Data_size*0.1); 
        Validation_size = fix(Train_size * validation_size);
        
        Learn_size =Train_size; %Validation_size + 
        Test_size = 20*24;%Learn_size;%
        
        % Set Generation: In this section the Learning and Test set are extracted from the Data set
        % Data = real(tubitex_cmplx_1h(:,u));
        Data = real(E_load_h_all(:,u));
        Overlap = 0;
        for d = N_of_set:-1:1
            input_index  = (1:max_input_size)  + d-1;
            output_index = (1:max_output_size) + d-1 + max_input_size - Overlap;
            set_Data(d,:)       = [Data(input_index); Data(output_index)];
            set_Data_index(d,:) = [hour_indexes(input_index); hour_indexes(output_index)];
        end
        
        %% Start of the loop, we can decide to performe multiple experiment in which we shift the chosed sets
        
        for m= max_m:-1:1 %m = 1%
            disp([u Elab_type m])
            %% Ordered Generation of Learn & Test set
            % dimension 1
            offset = (m-1)*30*24;
            stop_indx = Learn_size + Test_size;
        
            % dimension 2
            start_indx_2 = 1;
            stop_indx_2 = max_input_size + max_output_size;
        
            % Learn and Test set used
            Learn_set = set_Data(1+offset:Learn_size+offset,:);
            Test_set  = set_Data(Learn_size+1+offset:stop_indx+offset,:);
            Learn_set_index = set_Data_index(1+offset:Learn_size+offset,:);
            Test_set_index  = set_Data_index(Learn_size+1+offset:stop_indx+offset,:);
        
            Output_test_original = set_Data(Learn_size+1+offset:stop_indx+offset,max_input_size+1:max_input_size+max_output_size);
            Input_test_plot = Test_set;
        
        
            %% Benchmark: weighted mobile mean with exponential smoothing
            %%% Solution to forecast that not require neural networks, used as benchmark comparison
            options_wbench.memory_weight = 0.95;
            options_wbench.input_size = max_input_size;
            [Mean_sequence,Pers_sequence,Output_desired] = weight_benchmark(Learn_set, Test_set, options_wbench);
        
            %% Code for the different Input-Output size combination
            Input_size_indx = 1;
            Output_size_indx = 1;
        
                %% Setup 
                hiddenLayerSize_1 = hiddenLayerSize_1_list(Input_size_indx);
                hiddenLayerSize_2 = hiddenLayerSize_2_list(Input_size_indx);
                hidsize = [hiddenLayerSize_1 hiddenLayerSize_2];
        
                N_of_Input = Input_size_array(Input_size_indx);
                N_of_Output = Output_size_array(Output_size_indx);
                N_of_Input_app = N_of_Input;
                N_of_Output_app = N_of_Output;
                
                disp([m, N_of_Input, N_of_Output, hidsize, O1])
        
                %%% dimension of the set
                % dimensione 1
                offset = (m-1)*30*24;
                stop_indx = Learn_size + Test_size;
            
                % dimensione 2
                start_indx_2 = max_input_size - N_of_Input + 1;
                stop_indx_2 = max_input_size + N_of_Output;
        
                %% Preprocessing
                switch Elab_type
                    case 0 %% Normalization on Unit Circle
                    [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_unit_circle(Learn_set, Test_set, O1, O2, start_indx_2, stop_indx_2, N_of_Input);
        
                    case 1 %% Use of FFT    
                    [Input_learn_processed, Input_test_processed, max_matrix, ~,~, Sets] = preprocess_with_FFT(Learn_set, Test_set, N_of_Input, N_of_Output, start_indx_2, stop_indx_2);
                    max_input_learn = max_matrix.max_input_learn;
                    max_input_test = max_matrix.max_input_test;
        
                    case 2 %% Use of FFT and reduction of the size   
                    [Input_learn_processed, Input_test_processed, max_matrix, ~,~, Sets] = preprocess_with_FFT(Learn_set, Test_set, N_of_Input, N_of_Output, start_indx_2, stop_indx_2);
                    [Input_learn_processed, Input_test_processed, Input_learn_offset, Input_test_offset, N_of_Input_red, N_of_Output_red, Sets] = preprocess_with_FFT_2(Input_learn_processed, Input_test_processed, N_of_Input, N_of_Output, Sets); 
                    N_of_Input_app = N_of_Input_red;
                    N_of_Output_app = N_of_Output_red;
                    max_input_learn = max_matrix.max_input_learn;
                    max_input_test = max_matrix.max_input_test;
        
                    case 3 %% Normalization on Unit Circle + Days 
                    [Input_learn_processed, Input_test_processed, parameters, Sets] = preprocess_day_of_the_week(Learn_set, Test_set, O1, O2, start_indx_2, stop_indx_2, Learn_set_index, Test_set_index, N_of_Input);
                end
        
                Progr_Learning_MVN = Input_learn_processed;
                Progr_Testing_MVN = Input_test_processed;
                t2 = 'Input Processing Example';
                input_complex_plot(Sets.Learn_Original_Input, Sets.Learn_Processed_Input, t2, 98, 1);
        
                %% Training Rete Neurale
                % The Network whant a complex series of data whit every example
                % represented by a row. Each row have to be composed by N_of_Input
                % element followed by more N_of_Output 
        
                Progr_Learning_MVN_used = Progr_Learning_MVN;
        
                options_learn.hidneur_num = hidsize;
                options_learn.GlobalThreshold = 0.004;
                options_learn.max_iterations = n_epoch;
                options_learn.n_of_outputs = N_of_Output_app;
                options_learn.val_proportion = validation_size;
                options_learn.type = type;
                options_learn.plot_on = [0 0];
                options_learn.max_norm_on = 1;
        
                [Network, Learn_Results] = Net_learn_expanded(Progr_Learning_MVN_used, options_learn);
        
                % %% Post Training Elaboration
                % switch Elab_type
                %     case 0 %% Normalization on Unit Circle
                % 
                %     case 1 %% Use of FFT 
                %         fig1_N = 30;
                %         fig2_N = 31;
                %         [errors] = Post_training_process(Learn_Results, N_of_Input, N_of_Output, max_input_learn, fig1_N, fig2_N, N_of_Output_red, Input_learn_offset);
                % 
                %      case 2 %% Use of FFT 
                %         fig1_N = 30;
                %         fig2_N = 31;
                %         [errors] = Post_training_process_FFT2(Learn_Results, N_of_Input, N_of_Output, max_input_learn, fig1_N, fig2_N, N_of_Output_red, Input_learn_offset); 
                % 
                %     case 3 %% Week days
                % end
        
                %% Test Rete Neurale
                Progr_Testing_MVN_used = Progr_Testing_MVN;
                [Test_Results] = Net_test_expanded(Progr_Testing_MVN_used, Network);
        
                %% Post Test Elaboration
                switch Elab_type
                    case 0 %% Normalization on Unit Circle
                        % Parameters
                        Log_Norm = parameters.Log_Norm;
                        Log_min = parameters.Log_Min;
                        Log_Offset = parameters.Log_Offset;
                        % Test results
                        test_output = Test_Results.test_output;
        
                        test_output_used = mod(angle(test_output), 2*pi);
                        real_output_used_1 = ((test_output_used - Log_Offset)/Log_Norm) + Log_min;
                        real_output_used = (e.^real_output_used_1 -1);
        
                    case 1 %% Use of FFT 
                        test_output = Test_Results.test_output;
                        des_test_output = Test_Results.des_test_output;
        %                 [test_output] = postprocess_with_FFT_2(test_output, N_of_Output, N_of_Output_red, Input_test_offset);
        %                 [des_test_output] = postprocess_with_FFT_2(des_test_output, N_of_Output, N_of_Output_red, Input_test_offset);                
                        % mean_rho_val_error = errors.val_pre;
                        max_input_test_used = max_input_test(:,N_of_Input+1:end);
                        test_output_used = test_output;% + repmat(mean_rho_val_error,Test_size,1);
        %                 actual_output_used(:,1) = Input_test_offset;
                        
                        [real_output_used] = postprocess_2(test_output_used, N_of_Output, max_input_test_used);
        %                 real_output_used = real_output_used - repmat(mean_rho_val_error,Test_size,1);
        
                    case 2 %% Use of FFT 2 
                        test_output = Test_Results.test_output;
                        des_test_output = Test_Results.des_test_output;
                        [test_output] = postprocess_with_FFT_2(test_output, N_of_Output, N_of_Output_red, Input_test_offset);
                        [des_test_output] = postprocess_with_FFT_2(des_test_output, N_of_Output, N_of_Output_red, Input_test_offset);                
                        % mean_rho_val_error = errors.val_pre;
                        max_input_test_used = max_input_test(:,N_of_Input+1:end);
                        test_output_used = test_output;% + repmat(mean_rho_val_error,Test_size,1);
                        actual_output_used(:,1) = Input_test_offset;
                        
                        [real_output_used] = postprocess_2(test_output_used, N_of_Output, max_input_test_used);
                        % real_output_used = real_output_used - repmat(mean_rho_val_error,Test_size,1);
        
                    case 3 %% Weekdays
                        a=1;
                        test_output = Test_Results.test_output;
                        des_test_output = Test_Results.des_test_output;
                        [real_output_used, index_result] = postprocess_day_of_the_week(test_output, parameters, O1, O2);
                end
        
                size_output = size(real_output_used);
                real_output = real_output_used;%
                real_desired_output = Output_test_original(:,1:size_output(2));
        
                %% Metrics 
        
                %%% Metrics Evaluation
                [Metrics_Bench] = metrics_evaluation (Mean_sequence, Output_desired);
                [Metrics_Pers] = metrics_evaluation (Pers_sequence, Output_desired);
                [Metrics_Test] = metrics_evaluation (real_output, real_desired_output);
        
                Result_app(m).Output_desired      = Output_desired;
                Result_app(m).real_desired_output = real_desired_output;
                Result_app(m).Mean_sequence       = Mean_sequence;
                Result_app(m).Pers_sequence       = Pers_sequence;
                Result_app(m).Metrics_Bench       = Metrics_Bench;
                Result_app(m).Metrics_Pers        = Metrics_Pers;
                Result_app(m).Metrics_Test        = Metrics_Test;

                switch Elab_type
                    case 0
                        Result_app(m).UCircle_output    = real_output;
                        Result_app(m).Metrics_UCircle   = Metrics_Test;
                        
                    case 1
                        Result_app(m).FFT_output    = real_output;
                        Result_app(m).Metrics_FFT   = Metrics_Test;

                    case 2
                        Result_app(m).FFT2_output    = real_output;
                        Result_app(m).Metrics_FFT2   = Metrics_Test;

                    case 3
                        Result_app(m).WeekD_output    = real_output;
                        Result_app(m).Metrics_WeekD   = Metrics_Test;

                end
                Result_app(m).real_output         = real_output;
                Results(u).Montly_Result=Result_app;
                save Results_MLMVN.mat Results
        end
    end
end