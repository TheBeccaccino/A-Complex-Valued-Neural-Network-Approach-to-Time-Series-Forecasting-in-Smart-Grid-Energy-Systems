train_file = [x_train_app; t_train_app]';
dlmwrite('train_file.txt',train_file);

test_file = [x_test_app; t_test_app]';
dlmwrite('test_file.txt',test_file);
