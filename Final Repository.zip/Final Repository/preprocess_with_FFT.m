%% Preprocessing with FFT
function [Input_learn_processed, Input_test_processed, max_matrix, Input_learn_offset, Input_test_offset, Sets] = preprocess_with_FFT(Learn_set, Test_set, N_of_Input, N_of_Output, start_indx_2, stop_indx_2)
Learn_size = size(Learn_set,1);
Test_size = size(Test_set,1);

% Estrazione Input test dal dataset
Input_learn = Learn_set(:,start_indx_2:stop_indx_2);
Input_test = Test_set(:,start_indx_2:stop_indx_2);

% Logaritmic Normalization application
Input_learn_log = log(Input_learn+1);
Input_test_log = log(Input_test+1);

% Normalization based on the absolute maximum of the learning set
max_input_learn_app = max(Input_learn_log(:,1:N_of_Input),[],"all");
max_input_learn = repmat(max_input_learn_app,Learn_size,N_of_Input+N_of_Output);
max_input_test = repmat(max_input_learn_app,Test_size,N_of_Input+N_of_Output);

Input_learn_norm = Input_learn_log./max_input_learn;
Input_test_norm = Input_test_log./max_input_test;

%% FFT
%%% The FFT is applied on the divided Input & Output data and then stacked
%%% back togheter
% FFT Learning
Input_learn_2 = Input_learn_norm';
Input_learn_app = zeros(size(Input_learn_2));
Input_learn_app(1:N_of_Input,:) = fft(Input_learn_2(1:N_of_Input,:))/N_of_Input;
Input_learn_app(N_of_Input+1:end,:) = fft(Input_learn_2(N_of_Input+1:end,:))/N_of_Output;
Input_learn_app = Input_learn_app';

Input_learn_offset = Input_learn_app(:,1);
% Input_learn_app(:,1) = zeros(Learn_size,1);
% Input_learn_app(:,1+N_of_Input) = zeros(Learn_size,1);

% FFT Testing
Input_test_2 = Input_test_norm';
Input_test_app = zeros(size(Input_test_2));
Input_test_app(1:N_of_Input,:) = fft(Input_test_2(1:N_of_Input,:))/N_of_Input;
Input_test_app(N_of_Input+1:end,:) = fft(Input_test_2(N_of_Input+1:end,:))/N_of_Output;
Input_test_app = Input_test_app';

Input_test_offset = Input_test_app(:,1);
% Input_test_app(:,1) = zeros(Test_size,1);
% Input_test_app(:,1+N_of_Input) = zeros(Test_size,1);
  
%% Output
% Generazione Sets
Input_learn_processed = Input_learn_app;
Input_test_processed = Input_test_app;
% max matrix
max_matrix.max_input_learn = max_input_learn;
max_matrix.max_input_test = max_input_test;

% Sets
Sets.Learn_Original_Input   = Input_learn(:,1:N_of_Input);
Sets.Learn_Original_Output  = Input_learn(:,1:N_of_Input);
Sets.Learn_Processed_Input  = Input_learn_processed(:,1:N_of_Input);
Sets.Learn_Processed_Output = Input_learn_processed(:,N_of_Input+1:end);

Sets.Test_Original_Input   = Input_test(:,1:N_of_Input);
Sets.Test_Original_Output  = Input_test(:,1:N_of_Input);
Sets.Test_Processed_Input  = Input_test_processed(:,1:N_of_Input);
Sets.Test_Processed_Output = Input_test_processed(:,N_of_Input+1:end);