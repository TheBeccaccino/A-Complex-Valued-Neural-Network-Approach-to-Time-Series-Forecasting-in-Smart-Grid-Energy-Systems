function [a] = fft_plot(real_des_seq, real_seq, des_seq, seq, t, fig_N, indx)
            figure(fig_N)
            sgtitle(t) % 
            p = indx;

            subplot(1,2,2)
            plot(real_des_seq(p,:))
            title("Output of the Network: Real Postprocessed Output")
            hold on
            plot(abs(real_seq(p,:)))
            grid on
            legend('desired output', 'generated output')
            hold off

            subplot(2,2,1)
            plot(abs(des_seq(p,:)))
            title("Output of the Network: Spectrum magnitude")
            grid on
            hold on
            plot(abs(seq(p,:)))
            legend('desired output', 'generated output')
            hold off
    
            subplot(2,2,3)
            plot(angle(des_seq(p,:)))
            title("Output of the Network: Spectrum angle")
            grid on  
            hold on
            plot(angle(seq(p,:)))
            legend('desired output', 'generated output')
            hold off

            a=1;

