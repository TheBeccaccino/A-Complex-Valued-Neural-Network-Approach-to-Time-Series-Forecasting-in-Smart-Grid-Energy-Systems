function [output_info] = hidden_neuron_output_plot(Input, hid_outmat1, hid_outmat2, z_outneur, znet_d, Fig_N, Titolo)
size_input = size(Input);
size_h1 = size(hid_outmat1);
size_h2 = size(hid_outmat2);
size_output = size(z_outneur);

Input = Input';
hid_outmat1 = hid_outmat1';
hid_outmat2 = hid_outmat2';
z_outneur = z_outneur';

N = size_input(1);

%% Data Elaboration
%%% Unit Cilinder
tstart = tic;
N_slices = fix(N/100);
uni_circle_points = (0:0.01:1) * 2*pi;
size_unicirc = size(uni_circle_points);

x_uni_circ_app = cos(uni_circle_points)*0.98;
x_uni_circ = repmat(x_uni_circ_app,1,N_slices);

y_uni_circ_app = sin(uni_circle_points)*0.98;
y_uni_circ = repmat(y_uni_circ_app,1,N_slices);

z_uni_circ_app = repmat((1:N_slices)*100, size_unicirc(2), 1);
z_uni_circ = reshape(z_uni_circ_app, 1, []);

uni_circ_plot = [x_uni_circ; y_uni_circ; z_uni_circ];

%%% Plot In    
x_plot_In_app = real(Input);
x_plot_In = reshape(x_plot_In_app, 1, []);
y_plot_In_app = imag(Input);
y_plot_In = reshape(y_plot_In_app, 1, []);
z_plot_In_app = repmat((1:N), size_input(2),1);
z_plot_In = reshape(z_plot_In_app, 1, []);

max_in_plot = max(abs(Input),[],"all")*1.2;
In_to_plot = [x_plot_In; y_plot_In; z_plot_In];
    
%%% Plot h1
x_plot_h1_app = real(hid_outmat1);
x_plot_h1 = reshape(x_plot_h1_app, 1, []);
y_plot_h1_app = imag(hid_outmat1);
y_plot_h1 = reshape(y_plot_h1_app, 1, []);
z_plot_h1_app = repmat((1:N), size_h1(2),1);
z_plot_h1 = reshape(z_plot_h1_app, 1, []);

max_h1_plot = max(abs(hid_outmat1),[],"all")*1.2;
H1_to_plot = [x_plot_h1; y_plot_h1; z_plot_h1];

%%% Plot h2 
x_plot_h2_app = real(hid_outmat2);
x_plot_h2 = reshape(x_plot_h2_app, 1, []);
y_plot_h2_app = imag(hid_outmat2);
y_plot_h2 = reshape(y_plot_h2_app, 1, []);
z_plot_h2_app = repmat((1:N), size_h2(2),1);
z_plot_h2 = reshape(z_plot_h2_app, 1, []);

max_h2_plot = max(abs(hid_outmat2),[],"all")*1.2;
H2_to_plot = [x_plot_h2; y_plot_h2; z_plot_h2];

%%% Plot Out   
x_plot_out_app = real(z_outneur);
x_plot_out = reshape(x_plot_out_app, 1, []);
y_plot_out_app = imag(z_outneur);
y_plot_out = reshape(y_plot_out_app, 1, []);
z_plot_out_app = repmat((1:N), size_output(2),1);
z_plot_out = reshape(z_plot_out_app, 1, []);

max_out_plot = max(abs(z_outneur),[],"all")*1.2;
Out_to_plot = [x_plot_out; y_plot_out; z_plot_out];

% %%% Plot Out Des  
% x_plot_out_des_app = real(znet_d);
% x_plot_out_des = reshape(x_plot_out_des_app, 1, []);
% y_plot_out_des_app = imag(znet_d);
% y_plot_out_des = reshape(y_plot_out_des_app, 1, []);
% z_plot_out_des_app = repmat((1:108:N), 108*size_output(2),1);
% z_plot_out_des = reshape(z_plot_out_des_app, 1, []);
% 
% max_out_des_plot = max(abs(znet_d),[],"all")*1.2;
% Out_des_to_plot = [x_plot_out_des; y_plot_out_des; z_plot_out_des];

%% Plots
%%% Cilinder Plot
figure(Fig_N)
sgtitle("Results on the " + Titolo)

subplot(2,2,1)
plot3(uni_circ_plot(1,:), uni_circ_plot(2,:), uni_circ_plot(3,:))
hold on
plot3(In_to_plot(1,:), In_to_plot(2,:), In_to_plot(3,:), '.')
xlim([-max_in_plot, max_in_plot])
ylim([-max_in_plot, max_in_plot])   
grid on
title('Used Input')
xlabel('Real Axis'); ylabel('Imm. Axis'); zlabel('Samples'); 
% legend('unit circle', 'input data')
hold off

subplot(2,2,2)
plot3(uni_circ_plot(1,:), uni_circ_plot(2,:), uni_circ_plot(3,:))
hold on
plot3(H1_to_plot(1,:), H1_to_plot(2,:), H1_to_plot(3,:), '.')
xlim([-max_h1_plot, max_h1_plot])
ylim([-max_h1_plot, max_h1_plot])   
grid on
title('Output from h1')
xlabel('Real Axis'); ylabel('Imm. Axis'); zlabel('Samples'); 
% legend('unit circle', 'H1 output')
hold off

subplot(2,2,3)
plot3(uni_circ_plot(1,:), uni_circ_plot(2,:), uni_circ_plot(3,:))
hold on
plot3(H2_to_plot(1,:), H2_to_plot(2,:), H2_to_plot(3,:), '.')
xlim([-max_h2_plot, max_h2_plot])
ylim([-max_h2_plot, max_h2_plot])  
grid on
title('Output from h2')
xlabel('Real Axis'); ylabel('Imm. Axis'); zlabel('Samples'); 
% legend('unit circle', 'H2 output')
hold off

subplot(2,2,4)
plot3(uni_circ_plot(1,:), uni_circ_plot(2,:), uni_circ_plot(3,:))
hold on
plot3(Out_to_plot(1,:), Out_to_plot(2,:), Out_to_plot(3,:), '.', Color=[0.8500 0.3250 0.0980])
% plot3(Out_des_to_plot(1,:), Out_des_to_plot(2,:), Out_des_to_plot(3,:), '.', Color=[0.9290 0.6940 0.1250])
xlim([-max_out_plot, max_out_plot])
ylim([-max_out_plot, max_out_plot])   
grid on
title('Output from the Network')
xlabel('Real Axis'); ylabel('Imm. Axis'); zlabel('Samples'); 
% legend('unit circle', 'gen. output', 'des. output')
hold off

%% Polar Train Plot
figure(Fig_N + 1)
sgtitle("Results on the " + Titolo)

subplot(2,2,1)
plot(uni_circ_plot(1,:), uni_circ_plot(2,:))
hold on
plot(In_to_plot(1,:), In_to_plot(2,:), '.')
xlim([-max_in_plot, max_in_plot])
ylim([-max_in_plot, max_in_plot])   
grid on
title('Used Input')
xlabel('Real Axis'); ylabel('Imm. Axis');
hold off

subplot(2,2,2)
plot(uni_circ_plot(1,:), uni_circ_plot(2,:))
hold on
plot(H1_to_plot(1,:), H1_to_plot(2,:), '.')
xlim([-max_h1_plot, max_h1_plot])
ylim([-max_h1_plot, max_h1_plot])  
grid on
title('Output from h1')
xlabel('Real Axis'); ylabel('Imm. Axis');
hold off

subplot(2,2,3)
plot(uni_circ_plot(1,:), uni_circ_plot(2,:))
hold on
plot(H2_to_plot(1,:), H2_to_plot(2,:), '.')
xlim([-max_h2_plot, max_h2_plot])
ylim([-max_h2_plot, max_h2_plot])   
grid on
title('Output from h2')
xlabel('Real Axis'); ylabel('Imm. Axis');
hold off

subplot(2,2,4)
plot(uni_circ_plot(1,:), uni_circ_plot(2,:))
hold on
plot(Out_to_plot(1,:), Out_to_plot(2,:), '.')
% plot(Out_des_to_plot(1,:), Out_des_to_plot(2,:), '.')
xlim([-max_out_plot, max_out_plot])
ylim([-max_out_plot, max_out_plot])   
grid on
title('Output from the Network')
xlabel('Real Axis'); ylabel('Imm. Axis');
hold off

%% Flow of the information
figure(Fig_N + 2)

%% Output info
output_info.uni_circ_plot = uni_circ_plot;
output_info.In_to_plot = In_to_plot;
output_info.H1_to_plot = H1_to_plot;
output_info.H2_to_plot = H2_to_plot;
output_info.Out_to_plot = Out_to_plot;