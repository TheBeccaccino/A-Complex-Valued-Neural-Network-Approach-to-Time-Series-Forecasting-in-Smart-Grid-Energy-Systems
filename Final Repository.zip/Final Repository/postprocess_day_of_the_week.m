%% Preprocessing for normalization on unit circle
function [real_result, index_result] = postprocess_day_of_the_week(results, parameters, O1, O2)

%%% Normalizzazione sul cerchio unitario
max_sector = O1 + O2;
safe_sector = O2;
used_sector = O1;

%% parameters
Max_Train_Log = parameters.Log_Max;
Min_Train_Log = parameters.Log_Min;

%% Data elaboaration
Results_mod   = abs(results);
Results_phase = angle(results);

%%% Real consumption
real_result_app  = Results_mod * (Max_Train_Log - Min_Train_Log) + Min_Train_Log;
real_result = exp(real_result_app) - 1;

%%% Index of the day
index_result = Results_phase

